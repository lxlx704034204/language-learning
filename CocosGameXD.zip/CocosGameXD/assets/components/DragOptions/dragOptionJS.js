cc.Class({
    extends: cc.Component,

    properties: {
        option_node: cc.Node,
        label: cc.Label
    },
    onLoad: function () {
        this.node.on(cc.Node.EventType.TOUCH_START, this.touch_start.bind(this), this.node);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.touch_move, this.node);
        this.node.on(cc.Node.EventType.TOUCH_END, this.touch_end.bind(this), this.node);
    },
    init: function (gameJS, option, optionLength) {
        this.node.opacity = 255;
        this.gameJS = gameJS;
        this.option = option;//选项（选项，选项答案）
        this.label.string = option.optionContent;//读取选项答案
        this.optionNo = option.optionNo;
    },
    touch_start: function(evt){
        this.opacity = 150;
        this.startx = this.node.x;
        this.starty = this.node.y;
    },
    touch_end:function(evt){
        this.node.opacity = 255;
        var isTouch = this.check();
        if(isTouch){
            this.optionClick();
        }else{
            this.node.x = this.startx;
            this.node.y = this.starty;
        }
    },
    touch_move:function(evt){
        var delta = evt.touch.getDelta();
        this.x += delta.x;
        this.y += delta.y; 
    },
    check:function(){
        var node = this.questionNode;
        var self = this.node;
        if((!this.isSelected) && Math.abs( node.x - self.x ) < (node.width + self.width)/2 && Math.abs( node.y - self.y + 650 ) < (node.height + self.height)/2){
            return true;
        }
        return false;
    },
    optionClick: function () {
        this.node.opacity = 0;
        var self = this;
        self.updateState(false);
        this.scheduleOnce(function () {
            self.gameJS.selectAnswer(self.option);
        }, 0.2);
    },
    //按钮是否可点击
    updateState: function (interactable) {
        var buttonCom = this.option_node.getComponent(cc.Button);
        buttonCom.interactable = interactable;
    },
    setQuestionNode: function(questionNode){
        this.questionNode = questionNode;
    }
});
