"use strict";
cc._RF.push(module, 'cf7e7Hjl8pBApNKVzaPXR0c', 'config');
// scripts/config.js

"use strict";

//log日志开关
window.CONSOLE_LOG_OPEN = false;

cc._RF.pop();