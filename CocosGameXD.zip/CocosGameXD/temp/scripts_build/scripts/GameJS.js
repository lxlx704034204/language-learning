"use strict";
cc._RF.push(module, 'd92c8sRpIBMBKs/RzLIjTLN', 'GameJS');
// scripts/GameJS.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        fish_node: cc.Node,
        fish_1_prefab: cc.Prefab,
        fish_2_prefab: cc.Prefab,
        fish_3_prefab: cc.Prefab,

        feedback_node: cc.Node,
        timeLabel: cc.Label,
        paopao_bg: cc.Node, //泡泡背景
        paopao_prefab: cc.Prefab, //泡泡预制
        titlelabel: cc.Label,
        loseTime: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        document.addEventListener('resignActivePauseGame', function () {
            cc.director.pause();
            cc.game.pause();

            console.log('app just resign active.');
        });

        document.addEventListener('becomeActiveResumeGame', function () {
            if (cc.game.isPaused) {
                cc.game.resume();
            }
            if (cc.director.isPaused) {
                cc.director.resume();
            }
            console.log('app just become active.');
        });

        this.optionTypeArr = {
            "1": "shanxing",
            "2": "shexian",
            "3": "tuoyuan",
            "4": "xiangjiaoxian",
            "5": "zhengyuan",
            "6": "zhixian",
            "7": "changfangxing",
            "8": "chuizhixian",
            "9": "dunjiao",
            "10": "lingxing",
            "11": "pingxingxian",
            "12": "ruijiao",
            "13": "tixing",
            "14": "xianduan",
            "15": "zhengfangxing",
            "16": "zhijiao",
            "17": "pingxingsibianxing",
            "18": "ruijiaosanjiaoxing",
            "19": "zhijiaosanjiaoxing",
            "20": "dunjiaosanjiaoxing"
        };

        //预制小鱼
        this.prefabArr = [this.fish_1_prefab, this.fish_2_prefab, this.fish_3_prefab];

        this.answerTime = 0; //答题时间

        this.countDown = 15;
        this.timeCallback = this.timeCallbackFunc();

        //反馈
        this.feedbackJS = this.feedback_node.getComponent('ShowFeedback');

        //当前题目序号
        this.nowQuestionID = 0;

        this.questionArr = [];
        //收集数据
        this.answerInfoArr = [];
        //请求数据
        this.network = this.node.getComponent('NetworkJS');
        this.network.sendXHR(this);

        this.createPaopao();
    },

    createPaopao: function createPaopao() {
        //左边
        var width = this.node.width;
        var height = 1012.0;
        var paopaoX = [120, 40, 160, 80, 200];
        var posY = height / paopaoX.length;
        for (var index = 0; index < paopaoX.length; index++) {
            var paopao = cc.instantiate(this.paopao_prefab);
            paopao.x = paopaoX[index];
            paopao.y = -posY * index;
            this.paopao_bg.addChild(paopao);
        }
        //右边
        for (var index = 0; index < paopaoX.length; index++) {
            var paopao = cc.instantiate(this.paopao_prefab);
            paopao.x = width - paopaoX[index];
            paopao.y = -posY * index;
            this.paopao_bg.addChild(paopao);
        }
    },

    showFeedback: function showFeedback(type) {
        //龙虾反馈
        this.feedbackJS.showFeedback(type);

        this.nowQuestionID += 1;

        this.scheduleOnce(function () {
            if (this.nowQuestionID >= this.questionArr.length) {
                if (CONSOLE_LOG_OPEN) console.log('答完了');

                this.network.gameOver(this.answerInfoArr);
            } else {
                this.feedbackJS.animationStop();
                //移除当前所有选项
                this.deleteOption();
                //开始下一题
                this.startloadOption();
            }
        }, 2.0);
    },

    //显示减时间-5秒
    showLossTime: function showLossTime() {
        this.answerTime += 2;

        this.isShowLossTime = true;
        this.loseTime.active = true;
        //透明度渐变
        this.loseTime.opacity = 255;

        var callFunc = cc.callFunc(function (target) {
            this.isShowLossTime = false;
            this.loseTime.active = false;
        }, this);

        this.loseTime.runAction(cc.sequence(cc.fadeTo(1.0, 0), callFunc));
    },

    // //倒计时回调
    timeCallbackFunc: function timeCallbackFunc() {
        var timeCallback = function timeCallback() {
            //用户答题时间
            this.answerTime += 1;
            //倒计时次数
            this.scheduleTime += 1;

            var timeString = this.countDown - this.answerTime;

            if (timeString <= 0) {
                //时间到
                if (CONSOLE_LOG_OPEN) console.log('时间到');

                this.isShowFeed = true;

                this.answerTime = this.countDown;
                this.timeLabel.string = '00:00';

                this.createAnswerInfo('2');

                this.showFeedback(3);

                //是减时间，取消定时器,放在showFeedback，要不然会不执行scheduleOnce
                if (this.answerTime > this.scheduleTime) {
                    //取消定时器
                    this.unschedule(this.timeCallback);
                }
            } else if (timeString < 10) {
                this.timeLabel.string = '00:0' + timeString;
            } else {
                this.timeLabel.string = '00:' + timeString;
            }
        };
        return timeCallback;
    },

    //显示倒计时
    showSchedule: function showSchedule() {
        this.scheduleTime = 0;
        this.schedule(this.timeCallback, 1.0, this.countDown - 1);
    },

    //创建选项按钮
    createOption: function createOption(interactiveJson) {
        // console.log(interactiveJson);
        //{"count":"3","total_count":"10","type":"5","countDown":"15"}
        //正确答案数
        this.count = interactiveJson.count;
        //答案总数
        var totalCount = interactiveJson.total_count;
        //答案类型
        var optionType = this.optionTypeArr[interactiveJson.type];

        var interfereType = this.getInterfereType(interactiveJson.type);

        for (var index = 0; index < parseInt(this.count); index++) {
            var num = Math.round(Math.random() * (this.prefabArr.length - 1));
            //取随机答案
            var url = optionType + (num + 1);

            var fish = cc.instantiate(this.prefabArr[num]);
            var fishJS = fish.getComponent('Fish');
            fishJS.loadSprite(this, true, url);

            this.fish_node.addChild(fish);
        }

        for (var index = 0; index < parseInt(totalCount) - parseInt(this.count); index++) {
            var _num = Math.round(Math.random() * (this.prefabArr.length - 1));
            var typeNum = Math.round(Math.random() * (interfereType.length - 1));
            var url = interfereType[typeNum];
            //取随机答案
            url = url + (_num + 1);

            var fish = cc.instantiate(this.prefabArr[_num]);
            var fishJS = fish.getComponent('Fish');
            fishJS.loadSprite(this, false, url);

            this.fish_node.addChild(fish);
        }
    },

    //移除当前所有选项
    deleteOption: function deleteOption() {
        this.fish_node.destroyAllChildren();
        this.fish_node.removeAllChildren();
    },

    //开始加载选项
    startloadOption: function startloadOption() {
        var question = this.questionArr[this.nowQuestionID];

        this.titlelabel.string = question.qescont;

        //倒计时
        var countDown = parseInt(question.interactiveJson['countDown']);
        if (countDown > 0) {
            this.countDown = countDown;
        } else {
            this.countDown = 20;
        }
        this.timeLabel.string = '00:' + this.countDown;

        this.answerTime = 0;

        this.rightSelect = 0;

        this.createOption(question.interactiveJson);

        this.showSchedule();

        this.isShowFeed = false;
    },

    //题目下载完成，开始游戏
    startLoadGame: function startLoadGame(questionArr) {
        this.questionArr = questionArr;
        this.startloadOption();
    },

    //选中答案
    selectAnswer: function selectAnswer(target, isRight) {
        //显示状态过程中不接收事件
        if (this.isShowFeed || this.isShowLossTime) {
            return;
        }

        if (isRight) {
            if (CONSOLE_LOG_OPEN) console.log('答对了');

            this.rightSelect += 1;

            // console.log(this.rightSelect);

            target.showParticle();

            //题打完了
            if (this.rightSelect >= this.count) {
                //取消定时器
                this.unschedule(this.timeCallback);

                this.isShowFeed = true;

                this.createAnswerInfo('1');

                this.scheduleOnce(function () {
                    this.showFeedback(1);
                }, 1.0);
            }
        } else {
            if (CONSOLE_LOG_OPEN) console.log('答错了');

            this.showLossTime();
        }
    },

    // answerInfo['answerTime'] = '用时多少';
    // answerInfo['leveLQuestionDetailNum'] = 'IPS题目（小题）序号';
    // answerInfo['levelQuestionDetailID'] = 'IPS题目（小题） ID';
    // answerInfo['answerStatus'] = '答题状态 1：正确 2：错误';
    // answerInfo['answerContext'] = 'A/B/C/D';//用户答案选项
    createAnswerInfo: function createAnswerInfo(answerStatus) {
        var question = this.questionArr[this.nowQuestionID];

        //组装数据
        var answerInfo = {
            answerTime: this.answerTime,
            leveLQuestionDetailNum: question.leveLQuestionDetailNum,
            levelQuestionDetailID: question.levelQuestionDetailID,
            answerStatus: answerStatus,
            answerContext: ''
        };

        this.answerInfoArr.push(answerInfo);
    },

    getInterfereType: function getInterfereType(questionType) {
        var interfere = [];
        switch (questionType) {
            case '14':
                interfere.push('zhixian');
                interfere.push('shexian');
                break;
            case '6':
                interfere.push('xianduan');
                interfere.push('shexian');
                break;
            case '2':
                interfere.push('xianduan');
                interfere.push('zhixian');
                break;
            case '12':
                interfere.push('zhijiao');
                interfere.push('dunjiao');
                break;
            case '16':
                interfere.push('ruijiao');
                interfere.push('dunjiao');
                break;
            case '9':
                interfere.push('ruijiao');
                interfere.push('zhijiao');
                break;
            case '11':
                interfere.push('chuizhixian');
                interfere.push('xiangjiaoxian');
                break;
            case '4':
                interfere.push('pingxingxian');
                interfere.push('zhixian');
                break;
            case '3':
                interfere.push('zhengyuan');
                interfere.push('shanxing');
                break;
            case '8':
                interfere.push('pingxingxian');
                interfere.push('xiangjiaoxian');
                break;
            case '5':
                interfere.push('tuoyuan');
                interfere.push('shanxing');
                break;
            case '1':
                interfere.push('tuoyuan');
                interfere.push('zhengyuan');
                break;
            case '17':
                interfere.push('tixing');
                interfere.push('zhijiaosanjiaoxing');
                interfere.push('ruijiaosanjiaoxing');
                interfere.push('dunjiaosanjiaoxing');
                interfere.push('zhengyuan');
                break;
            case '13':
                interfere.push('pingxingsibianxing');
                interfere.push('changfangxing');
                interfere.push('zhengfangxing');
                break;
            case '7':
                interfere.push('tixing');
                interfere.push('pingxingsibianxing');
                break;
            case '15':
                interfere.push('tixing');
                interfere.push('pingxingsibianxing');
                interfere.push('changfangxing');
                break;
            case '18':
                interfere.push('zhijiaosanjiaoxing');
                interfere.push('dunjiaosanjiaoxing');
                break;
            case '19':
                interfere.push('ruijiaosanjiaoxing');
                interfere.push('dunjiaosanjiaoxing');
                break;
            case '20':
                interfere.push('zhijiaosanjiaoxing');
                interfere.push('ruijiaosanjiaoxing');
                break;
            default:
                interfere.push('shanxing');
                break;
        }
        return interfere;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();