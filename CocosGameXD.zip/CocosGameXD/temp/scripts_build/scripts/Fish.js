"use strict";
cc._RF.push(module, '282fbGDbCRHGLUYZxNL0wYj', 'Fish');
// scripts/Fish.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        fishSprite: cc.Sprite,
        texSprite: cc.Sprite,
        button: cc.Node,
        xinging_pre: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.speedX = (Math.random() * 2 - 1) * 0.5;
        this.speedY = (Math.random() * 2 - 1) * 0.5;

        if (this.speedX > 0) {
            this.speedX += 0.5;
            this.node.scaleX = 1;
        } else {
            this.speedX -= 0.5;
            this.node.scaleX = -1;
        }
        this.node.x = Math.random() * 1024 - this.node.width;
        this.node.y = Math.random() * 768 - this.node.height;
    },

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        this.node.x += this.speedX * 5;
        this.node.y += this.speedY * 5;

        if (Math.abs(this.node.x) >= 1024 - this.node.width / 2) {
            this.speedX = -this.speedX;
            if (this.speedX > 0) {
                this.node.scaleX = 1;
            } else {
                this.node.scaleX = -1;
            }
        }
        if (Math.abs(this.node.y) >= 768 - this.node.height / 2) {
            this.speedY = -this.speedY;
        }
    },

    loadSprite: function loadSprite(target, isRight, texUrl) {
        var tempStrite = this.texSprite;
        this.gameJS = target;
        this.isRight = isRight;
        cc.loader.loadRes(texUrl, cc.SpriteFrame, function (err, tex) {
            if (!err) {
                tempStrite.spriteFrame = tex;
            }
        });
    },

    selectOption: function selectOption() {
        this.gameJS.selectAnswer(this, this.isRight);
    },

    showParticle: function showParticle() {
        //按钮不可点击
        this.button.active = false;
        //隐藏图形
        this.texSprite.enabled = false;
        //隐藏鱼以及鱼动画
        var anim = this.node.getComponent(cc.Animation);
        anim.stop();

        this.fishSprite.enabled = false;

        //创建粒子效果动画，一组6个
        for (var index = 0; index < 2; index++) {
            var xingxing = cc.instantiate(this.xinging_pre);
            this.node.addChild(xingxing);
        }
    }
});

cc._RF.pop();