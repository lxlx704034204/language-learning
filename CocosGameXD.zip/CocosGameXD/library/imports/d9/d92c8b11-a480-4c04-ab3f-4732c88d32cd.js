'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        timeLabel: cc.Label,
        paopao_node: cc.Node, //泡泡背景
        paopao_pref: cc.Prefab, //泡泡预制
        feedback_node: cc.Node, //龙虾反馈
        feedback_pref: cc.Prefab, //龙虾预制
        loseTime_node: cc.Node, //减时间
        loseTime: 0, //减时间3秒
        questionTitle: cc.Label, // 题干
        option_node: cc.Node, // 选项
        option_node_pref: cc.Prefab, //
        question_node: cc.Node, // 题干小乌龟
        question_node_pref_z: cc.Prefab, //题干小乌龟(正常)
        question_node_pref_n: cc.Prefab },

    // use this for initialization
    onLoad: function onLoad() {
        //注册监听home键事件
        document.addEventListener('resignActivePauseGame', function () {
            cc.director.pause();
            cc.game.pause();

            console.log('app just resign active.');
        });
        document.addEventListener('becomeActiveResumeGame', function () {
            if (cc.game.isPaused) {
                cc.game.resume();
            }
            if (cc.director.isPaused) {
                cc.director.resume();
            }
            console.log('app just become active.');
        });

        //创建龙虾
        var feedback = cc.instantiate(this.feedback_pref);
        this.feedback_node.addChild(feedback);
        // 缓冲池
        this.answerItemPool = new cc.NodePool();
        //反馈
        this.feedbackJS = feedback.getComponent('ShowFeedback');
        //气泡
        this.createPaopao();
        //答题时间
        this.answerTime = 0;
        //'A/B/C/D',用户答案选项
        this.answerContext = '';
        //倒计时
        this.countDown = 3;
        //倒计时回调
        this.timeCallback = this.timeCallbackFunc();
        //是否在显示减时间
        this.isShowLossTime = false;
        //当前题目序号
        this.nowQuestionID = 0;
        //题目列表
        this.questionArr = [];
        //收集数据
        this.answerInfoArr = [];
        //请求数据
        this.network = this.node.getComponent('NetworkJS_Data');
        this.network.sendXHR(this);
        console.log(this.network);
        this.specialWugui = null;
    },

    //加载泡泡
    createPaopao: function createPaopao() {
        //左边
        var width = this.node.width;
        var height = 1012.0;
        var paopaoX = [120, 40, 160, 80, 200];
        var posY = height / paopaoX.length;
        for (var index = 0; index < paopaoX.length; index++) {
            var paopao = cc.instantiate(this.paopao_pref);
            paopao.x = paopaoX[index];
            paopao.y = -posY * index;
            this.paopao_node.addChild(paopao);
        }
        //右边
        for (var index = 0; index < paopaoX.length; index++) {
            var paopao = cc.instantiate(this.paopao_pref);
            paopao.x = width - paopaoX[index];
            paopao.y = -posY * index;
            this.paopao_node.addChild(paopao);
        }
    },

    // answerInfo['answerTime'] = '用时多少';
    // answerInfo['leveLQuestionDetailNum'] = 'IPS题目（小题）序号';
    // answerInfo['levelQuestionDetailID'] = 'IPS题目（小题） ID';
    // answerInfo['answerStatus'] = '答题状态 1：正确 2：错误';
    // answerInfo['answerContext'] = 'A/B/C/D';//用户答案选项
    createAnswerInfo: function createAnswerInfo(answerStatus) {
        var question = this.questionArr[this.nowQuestionID];
        //组装数据
        var answerInfo = {
            answerTime: this.answerTime,
            leveLQuestionDetailNum: question.leveLQuestionDetailNum,
            levelQuestionDetailID: question.levelQuestionDetailID,
            answerStatus: answerStatus,
            answerContext: this.answerContext
        };

        this.answerInfoArr.push(answerInfo);
    },

    //龙虾反馈
    showFeedback: function showFeedback(type) {
        //龙虾反馈
        this.feedbackJS.showFeedback(type);

        this.nowQuestionID += 1;
        //显示进度
        this.network.gameLoadProgress(this.nowQuestionID, this.questionArr.length);

        this.scheduleOnce(function () {
            if (this.nowQuestionID >= this.questionArr.length) {
                if (CONSOLE_LOG_OPEN) console.log('答完了');

                this.network.gameOver(this.answerInfoArr);
            } else {
                this.feedbackJS.animationStop();
                //移除当前所有选项
                this.deleteOption();
                //开始下一题
                this.startloadOption();
            }
        }, 2.0);
    },

    //显示减时间
    showLossTime: function showLossTime() {
        this.answerTime += this.loseTime;

        this.isShowLossTime = true;
        //透明度渐变
        this.loseTime_node.opacity = 255;

        var callFunc = cc.callFunc(function (target) {
            this.isShowLossTime = false;
            this.loseTime_node.opacity = 0;
        }, this);

        this.loseTime_node.runAction(cc.sequence(cc.fadeTo(1.0, 0), callFunc));
    },

    //倒计时回调
    timeCallbackFunc: function timeCallbackFunc() {
        var timeCallback = function timeCallback() {
            //用户答题时间
            this.answerTime += 1;
            //倒计时次数
            this.scheduleTime += 1;

            var timeString = this.countDown - this.answerTime;

            if (timeString <= 0) {
                //时间到
                if (CONSOLE_LOG_OPEN) console.log('时间到');

                this.isShowFeed = true;

                this.answerTime = this.countDown;
                this.timeLabel.string = '00:00';

                this.createAnswerInfo('2');

                this.showFeedback(3);

                //是减时间，取消定时器,放在showFeedback，要不然会不执行scheduleOnce
                if (this.answerTime > this.scheduleTime) {
                    //取消定时器
                    this.unschedule(this.timeCallback);
                }
            } else if (timeString < 10) {
                this.timeLabel.string = '00:0' + timeString;
            } else {
                this.timeLabel.string = '00:' + timeString;
            }
        };
        return timeCallback;
    },

    //显示倒计时
    showSchedule: function showSchedule() {
        this.scheduleTime = 0;
        this.schedule(this.timeCallback, 1.0, this.countDown - 1);
    },

    //移除当前所有选项
    deleteOption: function deleteOption() {
        var array = this.option_node.children;
        for (var i = 0; i < array.length;) {
            var tempOption = array[i];
            //放进对象池会自动调用removeFromParent
            this.answerItemPool.put(tempOption);
        }
    },

    //选项按钮不可用
    changeOptionEnable: function changeOptionEnable() {
        //暂停当前节点上注册的所有节点系统事件，节点系统事件包含触摸和鼠标事件。
        this.option_node.pauseSystemEvents(true);
    },

    //创建选项按钮
    createOption: function createOption(questionOptions) {
        for (var i = 0; i < questionOptions.length; ++i) {
            var optionItem = null;
            if (this.answerItemPool.size() > 0) {
                optionItem = this.answerItemPool.get();
            } else {
                optionItem = cc.instantiate(this.option_node_pref);
            }

            var optionJS = optionItem.getComponent('textJs');
            optionJS.textInit(this, questionOptions[i]);
            //按钮可用
            optionJS.updateState(true);
            this.option_node.addChild(optionItem);
        }
    },

    //创建小乌龟
    createWugui: function createWugui(questionContent) {
        this.question_node.removeAllChildren();
        var timeTemp = 0.2;
        for (var i = 0; i < questionContent.length; ++i) {
            var optionItem = null;
            if (questionContent[i] == '*') {
                this.specialWugui = cc.instantiate(this.question_node_pref_n);
                this.question_node.addChild(this.specialWugui);
                this.specialWugui.runAction(cc.moveTo(timeTemp, cc.p(0, 0)));
            } else {
                optionItem = cc.instantiate(this.question_node_pref_z);
                var label = optionItem.getChildByName('huangqiqiu').getChildByName('label');
                label.getComponent(cc.Label).string = questionContent[i];
                this.question_node.addChild(optionItem);
                optionItem.runAction(cc.moveTo(timeTemp, cc.p(0, 0)));
            }
            timeTemp += 0.2;
        }
        this.scheduleOnce(function () {
            this.option_node.resumeSystemEvents(true);
        }, 0.2 * questionContent.length);
    },

    //开始加载选项
    startloadOption: function startloadOption() {
        function deleteHtml(text) {
            return text.replace(/<[^>]+>/g, "");
        }
        var question = this.questionArr[this.nowQuestionID];
        //倒计时
        var countDown = parseInt(question.interactiveJson['countDown']);
        this.countDown = countDown;
        this.timeLabel.string = '00:' + this.countDown;
        this.questionTitle.string = '';
        this.questionTitle.string = deleteHtml(question.qescont);
        this.rightAnswer = question.questionCorrect;
        this.answerTime = 0;
        this.showSchedule();
        this.isShowFeed = false;
        this.createOption(question.questionOptions);
        this.changeOptionEnable();
        this.createWugui(question.interactiveJson['questionContent']);
    },

    //题目下载完成，开始游戏
    startLoadGame: function startLoadGame(questionArr) {
        this.questionArr = questionArr;
        //开始加载题目
        this.startloadOption();
    },

    //选中答案
    selectAnswer: function selectAnswer(optionNo) {
        this.changeOptionEnable();
        //显示状态过程中不接收事件
        if (this.isShowFeed || this.isShowLossTime) {
            return;
        }
        //取消定时器
        this.unschedule(this.timeCallback);
        this.isShowFeed = true;
        this.answerContext = optionNo;
        if (optionNo == this.rightAnswer) {
            this.createAnswerInfo('1');
            this.scheduleOnce(function () {
                this.showFeedback(1);
            }, 0.1);
        } else {
            this.createAnswerInfo('2');
            this.scheduleOnce(function () {
                this.showFeedback(2);
            }, 0.1);
        }
    },

    onDestroy: function onDestroy() {
        document.removeEventListener('resignActivePauseGame');
        document.removeEventListener('becomeActiveResumeGame');
    }

});