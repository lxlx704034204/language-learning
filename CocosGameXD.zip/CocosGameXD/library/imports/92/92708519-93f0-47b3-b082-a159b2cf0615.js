"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        label: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {},
    clickFun: function clickFun() {
        this.updateState(false);
        this.target.selectAnswer(this.textTemp.optionNo);
    },
    textInit: function textInit(target, textTemp) {
        this.label.string = textTemp.optionContent;
        this.target = target;
        this.textTemp = textTemp;
    },
    updateState: function updateState(state) {
        var buttonCom = this.node.getComponent(cc.Button);
        buttonCom.interactable = state;
    }

});