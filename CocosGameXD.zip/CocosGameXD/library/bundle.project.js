require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"GameJS":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'd92c8sRpIBMBKs/RzLIjTLN', 'GameJS');
// scripts/GameJS.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        timeLabel: cc.Label,
        paopao_node: cc.Node, //泡泡背景
        paopao_pref: cc.Prefab, //泡泡预制
        feedback_node: cc.Node, //龙虾反馈
        feedback_pref: cc.Prefab, //龙虾预制
        loseTime_node: cc.Node, //减时间
        loseTime: 0, //减时间3秒
        questionTitle: cc.Label, // 题干
        option_node: cc.Node, // 选项
        option_node_pref: cc.Prefab, //
        question_node: cc.Node, // 题干小乌龟
        question_node_pref_z: cc.Prefab, //题干小乌龟(正常)
        question_node_pref_n: cc.Prefab },

    // use this for initialization
    onLoad: function onLoad() {
        //注册监听home键事件
        document.addEventListener('resignActivePauseGame', function () {
            cc.director.pause();
            cc.game.pause();

            console.log('app just resign active.');
        });
        document.addEventListener('becomeActiveResumeGame', function () {
            if (cc.game.isPaused) {
                cc.game.resume();
            }
            if (cc.director.isPaused) {
                cc.director.resume();
            }
            console.log('app just become active.');
        });

        //创建龙虾
        var feedback = cc.instantiate(this.feedback_pref);
        this.feedback_node.addChild(feedback);
        // 缓冲池
        this.answerItemPool = new cc.NodePool();
        //反馈
        this.feedbackJS = feedback.getComponent('ShowFeedback');
        //气泡
        this.createPaopao();
        //答题时间
        this.answerTime = 0;
        //'A/B/C/D',用户答案选项
        this.answerContext = '';
        //倒计时
        this.countDown = 3;
        //倒计时回调
        this.timeCallback = this.timeCallbackFunc();
        //是否在显示减时间
        this.isShowLossTime = false;
        //当前题目序号
        this.nowQuestionID = 0;
        //题目列表
        this.questionArr = [];
        //收集数据
        this.answerInfoArr = [];
        //请求数据
        this.network = this.node.getComponent('NetworkJS_Data');
        this.network.sendXHR(this);
        console.log(this.network);
        this.specialWugui = null;
    },

    //加载泡泡
    createPaopao: function createPaopao() {
        //左边
        var width = this.node.width;
        var height = 1012.0;
        var paopaoX = [120, 40, 160, 80, 200];
        var posY = height / paopaoX.length;
        for (var index = 0; index < paopaoX.length; index++) {
            var paopao = cc.instantiate(this.paopao_pref);
            paopao.x = paopaoX[index];
            paopao.y = -posY * index;
            this.paopao_node.addChild(paopao);
        }
        //右边
        for (var index = 0; index < paopaoX.length; index++) {
            var paopao = cc.instantiate(this.paopao_pref);
            paopao.x = width - paopaoX[index];
            paopao.y = -posY * index;
            this.paopao_node.addChild(paopao);
        }
    },

    // answerInfo['answerTime'] = '用时多少';
    // answerInfo['leveLQuestionDetailNum'] = 'IPS题目（小题）序号';
    // answerInfo['levelQuestionDetailID'] = 'IPS题目（小题） ID';
    // answerInfo['answerStatus'] = '答题状态 1：正确 2：错误';
    // answerInfo['answerContext'] = 'A/B/C/D';//用户答案选项
    createAnswerInfo: function createAnswerInfo(answerStatus) {
        var question = this.questionArr[this.nowQuestionID];
        //组装数据
        var answerInfo = {
            answerTime: this.answerTime,
            leveLQuestionDetailNum: question.leveLQuestionDetailNum,
            levelQuestionDetailID: question.levelQuestionDetailID,
            answerStatus: answerStatus,
            answerContext: this.answerContext
        };

        this.answerInfoArr.push(answerInfo);
    },

    //龙虾反馈
    showFeedback: function showFeedback(type) {
        //龙虾反馈
        this.feedbackJS.showFeedback(type);

        this.nowQuestionID += 1;
        //显示进度
        this.network.gameLoadProgress(this.nowQuestionID, this.questionArr.length);

        this.scheduleOnce(function () {
            if (this.nowQuestionID >= this.questionArr.length) {
                if (CONSOLE_LOG_OPEN) console.log('答完了');

                this.network.gameOver(this.answerInfoArr);
            } else {
                this.feedbackJS.animationStop();
                //移除当前所有选项
                this.deleteOption();
                //开始下一题
                this.startloadOption();
            }
        }, 2.0);
    },

    //显示减时间
    showLossTime: function showLossTime() {
        this.answerTime += this.loseTime;

        this.isShowLossTime = true;
        //透明度渐变
        this.loseTime_node.opacity = 255;

        var callFunc = cc.callFunc(function (target) {
            this.isShowLossTime = false;
            this.loseTime_node.opacity = 0;
        }, this);

        this.loseTime_node.runAction(cc.sequence(cc.fadeTo(1.0, 0), callFunc));
    },

    //倒计时回调
    timeCallbackFunc: function timeCallbackFunc() {
        var timeCallback = function timeCallback() {
            //用户答题时间
            this.answerTime += 1;
            //倒计时次数
            this.scheduleTime += 1;

            var timeString = this.countDown - this.answerTime;

            if (timeString <= 0) {
                //时间到
                if (CONSOLE_LOG_OPEN) console.log('时间到');

                this.isShowFeed = true;

                this.answerTime = this.countDown;
                this.timeLabel.string = '00:00';

                this.createAnswerInfo('2');

                this.showFeedback(3);

                //是减时间，取消定时器,放在showFeedback，要不然会不执行scheduleOnce
                if (this.answerTime > this.scheduleTime) {
                    //取消定时器
                    this.unschedule(this.timeCallback);
                }
            } else if (timeString < 10) {
                this.timeLabel.string = '00:0' + timeString;
            } else {
                this.timeLabel.string = '00:' + timeString;
            }
        };
        return timeCallback;
    },

    //显示倒计时
    showSchedule: function showSchedule() {
        this.scheduleTime = 0;
        this.schedule(this.timeCallback, 1.0, this.countDown - 1);
    },

    //移除当前所有选项
    deleteOption: function deleteOption() {
        var array = this.option_node.children;
        for (var i = 0; i < array.length;) {
            var tempOption = array[i];
            //放进对象池会自动调用removeFromParent
            this.answerItemPool.put(tempOption);
        }
    },

    //选项按钮不可用
    changeOptionEnable: function changeOptionEnable() {
        //暂停当前节点上注册的所有节点系统事件，节点系统事件包含触摸和鼠标事件。
        this.option_node.pauseSystemEvents(true);
    },

    //创建选项按钮
    createOption: function createOption(questionOptions) {
        for (var i = 0; i < questionOptions.length; ++i) {
            var optionItem = null;
            if (this.answerItemPool.size() > 0) {
                optionItem = this.answerItemPool.get();
            } else {
                optionItem = cc.instantiate(this.option_node_pref);
            }

            var optionJS = optionItem.getComponent('textJs');
            optionJS.textInit(this, questionOptions[i]);
            //按钮可用
            optionJS.updateState(true);
            this.option_node.addChild(optionItem);
        }
    },

    //创建小乌龟
    createWugui: function createWugui(questionContent) {
        this.question_node.removeAllChildren();
        var timeTemp = 0.2;
        for (var i = 0; i < questionContent.length; ++i) {
            var optionItem = null;
            if (questionContent[i] == '*') {
                this.specialWugui = cc.instantiate(this.question_node_pref_n);
                this.question_node.addChild(this.specialWugui);
                this.specialWugui.runAction(cc.moveTo(timeTemp, cc.p(0, 0)));
            } else {
                optionItem = cc.instantiate(this.question_node_pref_z);
                var label = optionItem.getChildByName('huangqiqiu').getChildByName('label');
                label.getComponent(cc.Label).string = questionContent[i];
                this.question_node.addChild(optionItem);
                optionItem.runAction(cc.moveTo(timeTemp, cc.p(0, 0)));
            }
            timeTemp += 0.2;
        }
        this.scheduleOnce(function () {
            this.option_node.resumeSystemEvents(true);
        }, 0.2 * questionContent.length);
    },

    //开始加载选项
    startloadOption: function startloadOption() {
        function deleteHtml(text) {
            return text.replace(/<[^>]+>/g, "");
        }
        var question = this.questionArr[this.nowQuestionID];
        //倒计时
        var countDown = parseInt(question.interactiveJson['countDown']);
        this.countDown = countDown;
        this.timeLabel.string = '00:' + this.countDown;
        this.questionTitle.string = '';
        this.questionTitle.string = deleteHtml(question.qescont);
        this.rightAnswer = question.questionCorrect;
        this.answerTime = 0;
        this.showSchedule();
        this.isShowFeed = false;
        this.createOption(question.questionOptions);
        this.changeOptionEnable();
        this.createWugui(question.interactiveJson['questionContent']);
    },

    //题目下载完成，开始游戏
    startLoadGame: function startLoadGame(questionArr) {
        this.questionArr = questionArr;
        //开始加载题目
        this.startloadOption();
    },

    //选中答案
    selectAnswer: function selectAnswer(optionNo) {
        this.changeOptionEnable();
        //显示状态过程中不接收事件
        if (this.isShowFeed || this.isShowLossTime) {
            return;
        }
        //取消定时器
        this.unschedule(this.timeCallback);
        this.isShowFeed = true;
        this.answerContext = optionNo;
        if (optionNo == this.rightAnswer) {
            this.createAnswerInfo('1');
            this.scheduleOnce(function () {
                this.showFeedback(1);
            }, 0.1);
        } else {
            this.createAnswerInfo('2');
            this.scheduleOnce(function () {
                this.showFeedback(2);
            }, 0.1);
        }
    },

    onDestroy: function onDestroy() {
        document.removeEventListener('resignActivePauseGame');
        document.removeEventListener('becomeActiveResumeGame');
    }

});

cc._RF.pop();
},{}],"NetworkJS_Data":[function(require,module,exports){
"use strict";
cc._RF.push(module, '8febaBdc6ZNMK6NnHe3UpZb', 'NetworkJS_Data');
// scripts/NetworkJS_Data.js

'use strict';

var NetworkJS = require("NetworkJS");

cc.Class({
	extends: NetworkJS,

	properties: {},

	//解析转换每一条数据
	analysisDict: function analysisDict(questionDict) {
		var interactiveJson = questionDict.interactiveJson;
		if (!interactiveJson || interactiveJson.length == 0) {
			//容错不录json的情况
			this.gameLoadFailed(2);
			return;
		} else if (typeof interactiveJson == 'string') {
			interactiveJson = JSON.parse(interactiveJson);
		}
		var optionandanswer = questionDict.optionandanswers[0];

		var options = optionandanswer.options;

		var optionsArr = [];
		for (var i = 0; i < options.length; ++i) {
			var option = options[i];
			var optioncontent = option.optioncontent;
			var temp = {
				optionNo: option.optionno, //选项
				optionContent: this.removeSpan(optioncontent) };
			optionsArr.push(temp);
		}
		//每一道小题内容
		var question = {
			answerTime: '0', //答题时间
			levelQuestionDetailID: questionDict.questionid, //IPS题目（小题） ID
			leveLQuestionDetailNum: questionDict.orderid, //IPS题目（小题）序号
			qescont: this.removeSpan(questionDict.qescont), //题干
			interactiveJson: interactiveJson, //格外配置json
			questionOptions: optionsArr, // 题干选项
			questionCorrect: this.removeSpan(optionandanswer.rightanswer)
		};
		return question;
	}
});

cc._RF.pop();
},{"NetworkJS":"NetworkJS"}],"NetworkJS":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'cd804MyCfRHi4BLiy+Orkth', 'NetworkJS');
// scripts/NetworkJS.js

"use strict";

var NetworkJS = cc.Class({
	extends: cc.Component,

	properties: {},

	//解析url参数
	GetQueryString: function GetQueryString(name) {
		var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
		var r = window.location.search.substr(1).match(reg);
		if (r != null) return decodeURI(r[2]);return null;
	},

	sendXHR: function sendXHR(racingjs) {
		this.racingjs = racingjs;

		var xhr = cc.loader.getXMLHttpRequest();
		this.streamXHREventsToLabel(xhr, 'GET');

		//题库
		var fileUrl = this.GetQueryString('fileUrl');
		xhr.open("GET", fileUrl);

		if (cc.sys.isNative) {
			xhr.setRequestHeader("Accept-Encoding", "gzip,deflate");
		}

		// note: In Internet Explorer, the timeout property may be set only after calling the open()
		// method and before calling the send() method.
		xhr.timeout = 60000; //timeout

		xhr.send();
	},

	streamXHREventsToLabel: function streamXHREventsToLabel(xhr, method, responseHandler) {
		var handler = responseHandler || function (response) {
			return method + " Response: " + response.substring(0, 30) + '...';
		};

		var self = this;
		// Special event
		xhr.onreadystatechange = function () {
			try {
				if (xhr.readyState === XMLHttpRequest.DONE) {
					if (CONSOLE_LOG_OPEN) console.log(handler(xhr.responseText));
					if (xhr.status === 200) {
						// self.hideProgressBar();
						self.analysisData(xhr.responseText);
					} else {
						if (CONSOLE_LOG_OPEN) console.log('There was a problem with the request.');
						//下载失败反馈结果
						self.gameLoadFailed(1);
					}
				}
			} catch (e) {
				if (CONSOLE_LOG_OPEN) console.log('Caught Exception: ' + e.description);
				//下载失败反馈结果
				self.gameLoadFailed(1);
			}
		};
	},

	//解析数据
	analysisData: function analysisData(responseText) {
		var questions = JSON.parse(responseText);

		if (questions || questions.length > 0) {
			var questionArr = [];
			for (var i = 0; i < questions.length; ++i) {

				var question = this.analysisDict(questions[i]);

				questionArr.push(question);
			}
			if (questionArr && questionArr.length > 0) {
				this.racingjs.startLoadGame(questionArr);
				//通知游戏加载成功，开始游戏
				this.gameLoadSuccess(questionArr.length);
			} else {
				this.gameLoadFailed(2);
			}
		} else {
			this.gameLoadFailed(2);
		}
	},
	//解析转换每一条数据
	analysisDict: function analysisDict(questionDict) {
		var interactiveJson = questionDict.interactiveJson;
		if (!interactiveJson || interactiveJson.length == 0) {
			//容错不录json的情况
			this.gameLoadFailed(2);
			return;
		} else if (typeof interactiveJson == 'string') {
			interactiveJson = JSON.parse(interactiveJson);
		}
		//每一道小题内容
		var question = {
			answerTime: '0', //答题时间
			levelQuestionDetailID: questionDict.questionid, //IPS题目（小题） ID
			leveLQuestionDetailNum: questionDict.orderid, //IPS题目（小题）序号
			qescont: this.removeSpan(questionDict.qescont), //题干
			interactiveJson: interactiveJson };

		return question;
	},

	//过滤标签
	removeSpan: function removeSpan(spanString) {
		var newStr = spanString.replace('<span>', '');
		newStr = newStr.replace('</span>', '');

		return newStr;
	},

	//下载解析失败type:1.下载失败，2.解析失败
	gameLoadFailed: function gameLoadFailed(type) {
		if (!CONSOLE_LOG_OPEN) {
			if (type == 1) {
				var params = encodeURI('errcode=10001&errmsg=下载失败');
				//window.location.href = 'optionBlank://gameLoadFailed?' + params;
			} else {
				var params = encodeURI('errcode=10002&errmsg=解析失败');
				//window.location.href = 'optionBlank://gameLoadFailed?' + params;
			}
		}
	},

	//通知游戏加载成功，开始游戏
	gameLoadSuccess: function gameLoadSuccess(totalNumber) {
		if (!CONSOLE_LOG_OPEN) {
			var params = encodeURI('totalNumber=' + totalNumber);
			//window.location.href = 'optionBlank://gameLoadSuccess?' + params;
		}
	},

	//通知游戏结束
	gameOver: function gameOver(answerInfoArr) {
		var data = encodeURI(JSON.stringify(answerInfoArr));

		if (CONSOLE_LOG_OPEN) console.log('dataJson=' + JSON.stringify(answerInfoArr));

		if (!CONSOLE_LOG_OPEN) {
			//window.location.href = 'optionBlank://gameOver?status=1&data=' + data;
		}
	},
	//通知游戏加载成功，开始游戏
	gameLoadProgress: function gameLoadProgress(nowNumber, totalNumber) {
		if (!CONSOLE_LOG_OPEN) {
			var params = encodeURI('nowNumber=' + nowNumber + '&totalNumber=' + totalNumber);
			//window.location.href = 'optionBlank://gameLoadProgress?' + params;
		}
	}

});

cc._RF.pop();
},{}],"OptionJS":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'cec4fBlGJ1Nw5Qzjr1JzrRx', 'OptionJS');
// components/Options/OptionJS.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        option_node: cc.Node,
        label: cc.Label
    },

    init: function init(gameJS, option, optionLength) {
        this.gameJS = gameJS;
        this.option = option; //选项（选项，选项答案）
        this.label.string = option.optionContent; //读取选项答案
        this.optionNo = option.optionNo;
    },

    optionClick: function optionClick() {
        var self = this;
        self.updateState(false);
        this.scheduleOnce(function () {
            self.gameJS.selectAnswer(self.option);
        }, 0.2);
    },
    //按钮是否可点击
    updateState: function updateState(interactable) {
        var buttonCom = this.option_node.getComponent(cc.Button);
        buttonCom.interactable = interactable;
    }
});

cc._RF.pop();
},{}],"PaoPaoJS":[function(require,module,exports){
"use strict";
cc._RF.push(module, '64af7fqo+JH17aITx262Fhi', 'PaoPaoJS');
// components/Paopao/PaoPaoJS.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        paopao: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.paopao.scale = Math.random() * 0.7 + 0.3;
        // this.offsetX = (Math.random() * 2 - 1) * 0.1;
    },

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        // this.paopao.x += this.offsetX;
        this.paopao.y += 2.0;
        if (this.paopao.y >= 1012) {
            this.paopao.scale = Math.random() * 0.7 + 0.3;
            this.paopao.y = 0.0;
        }
    }
});

cc._RF.pop();
},{}],"ShowFeedback":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'd71f7iAMRpFbZk1pVUk7ZT9', 'ShowFeedback');
// components/Feedback/ShowFeedback.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        feedback: cc.Node,
        longxia: cc.Node,
        gongxini: cc.Node,
        yaojiayou: cc.Node,
        shijiandao: cc.Node
    },

    showFeedback: function showFeedback(feedbackType) {
        this.longxiaAnim = this.longxia.getComponent(cc.Animation);

        this.feedback.opacity = 255;
        this.longxia.opacity = 255;
        //透明度渐变
        this.feedback.opacity = 0;
        this.feedback.runAction(cc.sequence(cc.fadeTo(1, 255)));

        if (feedbackType === 1) {
            //答对了
            this.longxiaAnim.play('Feedback_1');

            this.gongxini.opacity = 255;
            this.yaojiayou.opacity = 0;
            this.shijiandao.opacity = 0;
        } else if (feedbackType === 2) {
            //答错了
            this.longxiaAnim.play('Feedback_2');

            this.gongxini.opacity = 0;
            this.yaojiayou.opacity = 255;
            this.shijiandao.opacity = 0;
        } else {
            //时间到
            this.longxiaAnim.play('Feedback_3');

            this.gongxini.opacity = 0;
            this.yaojiayou.opacity = 0;
            this.shijiandao.opacity = 255;
        }
    },

    animationStop: function animationStop() {
        this.longxiaAnim.stop();

        this.feedback.opacity = 0;
        this.longxia.opacity = 0;
    }
});

cc._RF.pop();
},{}],"XingxingJS":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'ea220VjaTtGaLQzyud5gsYc', 'XingxingJS');
// components/Xingxing/XingxingJS.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        this.node.scale = Math.random();
        //运行动画
        this.node.runAction(cc.sequence(cc.spawn(cc.moveBy(0.5, cc.p(280 * (Math.random() * 2 - 1), 280 * (Math.random() * 2 - 1))), cc.scaleTo(0.5, Math.random() * 0.5 + 0.5), cc.rotateBy(0.5, Math.random() * 90)), cc.callFunc(function () {
            this.node.active = false;
        }, this)));
    }
});

cc._RF.pop();
},{}],"config":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'cf7e7Hjl8pBApNKVzaPXR0c', 'config');
// scripts/config.js

'use strict';

//log日志开关
window.CONSOLE_LOG_OPEN = true;

//转换16进制颜色为rgb
function HEX2RGB(hexColor) {
	return {
		r: parseInt(hexColor.slice(1, 3), 16),
		g: parseInt(hexColor.slice(3, 5), 16),
		b: parseInt(hexColor.slice(5, 7), 16)
	};
}

function RGB2HEX(r, g, b) {
	var color = '#' + str_pad(Math.floor(r).toString(16), 2, '0') + str_pad(Math.floor(g).toString(16), 2, '0') + str_pad(Math.floor(b).toString(16), 2, '0');
	return color;
}
//去除收尾空格
function trim(value) {
	var temp = value;
	var obj = /^(\s*)([\W\w]*)(\b\s*$)/;
	if (obj.test(temp)) {
		temp = temp.replace(obj, '$2');
	}
	obj = /^(\s*)$/;
	if (obj.test(temp)) {
		temp = '';
	}

	return temp;
}
//转换为整数
function toInt(str) {
	var result = parseInt(str, 10);
	return isNaN(result) ? 0 : result;
}
//是否为数字
function isNum(num) {
	var rule = /^\d+$/;
	if (rule.test(num)) return true;
	return false;
}
//取min-max区间的随机数
function rand(min, max) {
	var Range = max - min;
	var Rand = Math.random();
	return min + Math.round(Rand * Range);
}
/**
 * 统计字符串长度，中文2的长度
 * @returns
 */
String.prototype.len = function () {
	return this.replace(/[^\x00-\xff]/g, "**").length;
};
/**
 * 字符串截取
 * @param len
 * @returns
 */
String.prototype.cutStr = function (n) {
	var r = /[^\x00-\xff]/g;

	if (this.replace(r, "**").length <= n) return this;
	var new_str = "";
	var str = "";
	for (var i = 0, j = 0; i < this.length && j < n; i++) {
		str = this.substr(i, 1);
		new_str += str;
		j += str.replace(r, "**").length > 1 ? 2 : 1;
	}
	return new_str + " ..";
};
/**
 * 替换字符串中的字符
 * @param str
 * @param replace_what
 * @param replace_with
 * @returns
 */
function str_replace(str, replace_what, replace_with) {
	var ndx = str.indexOf(replace_what);
	var delta = replace_with.length - replace_what.length;
	while (ndx >= 0) {
		str = str.substring(0, ndx) + replace_with + str.substring(ndx + replace_what.length);
		ndx = str.indexOf(replace_what, ndx + delta + 1);
	}
	return str;
}
// alert( readCookie("myCookie") );
function readCookie(name) {
	var cookieValue = "";
	var search = name + "=";
	if (document.cookie.length > 0) {
		offset = document.cookie.indexOf(search);
		if (offset != -1) {
			offset += search.length;
			end = document.cookie.indexOf(";", offset);
			if (end == -1) end = document.cookie.length;
			cookieValue = unescape(document.cookie.substring(offset, end));
		}
	}
	return cookieValue;
}
//time=秒
function writeCookie(name, value, time) {
	var expire = "";
	if (time != null) {
		//domain=.baidu.com
		expire = new Date(new Date().getTime() + time * 1000);
		expire = "; expires=" + expire.toGMTString();
	}
	expire += "; path=/";

	document.cookie = name + "=" + escape(value) + expire;
}

function getTime() {
	return new Date().getTime();
}

//=====解决js浮点运算bug<<<

//除法函数，用来得到精确的除法结果
//调用：accDiv(arg1,arg2)
//返回值：arg1除以arg2的精确结果
function accDiv(arg1, arg2) {}
// var t1 = 0,
// 	t2 = 0,
// 	r1, r2;
// try {
// 	t1 = arg1.toString().split(".")[1].length
// } catch (e) {}
// try {
// 	t2 = arg2.toString().split(".")[1].length
// } catch (e) {}
// with(Math) {
// 	r1 = Number(arg1.toString().replace(".", ""))
// 	r2 = Number(arg2.toString().replace(".", ""))
// 	return (r1 / r2) * pow(10, t2 - t1);
// }

//给Number类型增加一个div方法，调用起来更加方便。
Number.prototype.div = function (arg) {
	return accDiv(this, arg);
};
//乘法函数，用来得到精确的乘法结果
//调用：accMul(arg1,arg2)
//返回值：arg1乘以arg2的精确结果
function accMul(arg1, arg2) {
	var m = 0,
	    s1 = arg1.toString(),
	    s2 = arg2.toString();
	try {
		m += s1.split(".")[1].length;
	} catch (e) {}
	try {
		m += s2.split(".")[1].length;
	} catch (e) {}
	return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m);
}

//给Number类型增加一个mul方法，调用起来更加方便。
Number.prototype.mul = function (arg) {
	return accMul(arg, this);
};

//加法函数，用来得到精确的加法结果
//调用：accAdd(arg1,arg2)
//返回值：arg1加上arg2的精确结果
function accAdd(arg1, arg2) {
	var r1, r2, m;
	try {
		r1 = arg1.toString().split(".")[1].length;
	} catch (e) {
		r1 = 0;
	}
	try {
		r2 = arg2.toString().split(".")[1].length;
	} catch (e) {
		r2 = 0;
	}
	m = Math.pow(10, Math.max(r1, r2));
	return (arg1 * m + arg2 * m) / m;
}

//给Number类型增加一个add方法，调用起来更加方便。
Number.prototype.add = function (arg) {
	return accAdd(arg, this);
};

//减法函数，用来得到精确的减法结果
//调用：accSub(arg1,arg2)
//返回值：arg1减去arg2的精确结果
function accSub(arg1, arg2) {
	var r1, r2, m, n;
	try {
		r1 = arg1.toString().split(".")[1].length;
	} catch (e) {
		r1 = 0;
	}
	try {
		r2 = arg2.toString().split(".")[1].length;
	} catch (e) {
		r2 = 0;
	}
	m = Math.pow(10, Math.max(r1, r2));
	// last modify by deeka
	// 动态控制精度长度
	n = r1 >= r2 ? r1 : r2;
	return ((arg1 * m - arg2 * m) / m).toFixed(n);
}

//给Number类型增加一个add方法，调用起来更加方便。
Number.prototype.sub = function (arg) {
	return accSub(arg, this);
};
// =====解决js浮点运算bug>>>

cc._RF.pop();
},{}],"dragOptionJS":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'fa5adP1FHZPDLRNaX+1i0Ag', 'dragOptionJS');
// components/DragOptions/dragOptionJS.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        option_node: cc.Node,
        label: cc.Label
    },
    onLoad: function onLoad() {
        this.node.on(cc.Node.EventType.TOUCH_START, this.touch_start.bind(this), this.node);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.touch_move, this.node);
        this.node.on(cc.Node.EventType.TOUCH_END, this.touch_end.bind(this), this.node);
    },
    init: function init(gameJS, option, optionLength) {
        this.node.opacity = 255;
        this.gameJS = gameJS;
        this.option = option; //选项（选项，选项答案）
        this.label.string = option.optionContent; //读取选项答案
        this.optionNo = option.optionNo;
    },
    touch_start: function touch_start(evt) {
        this.opacity = 150;
        this.startx = this.node.x;
        this.starty = this.node.y;
    },
    touch_end: function touch_end(evt) {
        this.node.opacity = 255;
        var isTouch = this.check();
        if (isTouch) {
            this.optionClick();
        } else {
            this.node.x = this.startx;
            this.node.y = this.starty;
        }
    },
    touch_move: function touch_move(evt) {
        var delta = evt.touch.getDelta();
        this.x += delta.x;
        this.y += delta.y;
    },
    check: function check() {
        var node = this.questionNode;
        var self = this.node;
        if (!this.isSelected && Math.abs(node.x - self.x) < (node.width + self.width) / 2 && Math.abs(node.y - self.y + 650) < (node.height + self.height) / 2) {
            return true;
        }
        return false;
    },
    optionClick: function optionClick() {
        this.node.opacity = 0;
        var self = this;
        self.updateState(false);
        this.scheduleOnce(function () {
            self.gameJS.selectAnswer(self.option);
        }, 0.2);
    },
    //按钮是否可点击
    updateState: function updateState(interactable) {
        var buttonCom = this.option_node.getComponent(cc.Button);
        buttonCom.interactable = interactable;
    },
    setQuestionNode: function setQuestionNode(questionNode) {
        this.questionNode = questionNode;
    }
});

cc._RF.pop();
},{}],"textJs":[function(require,module,exports){
"use strict";
cc._RF.push(module, '92708UZk/BHs7CCoVmyzwYV', 'textJs');
// scripts/textJs.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        label: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {},
    clickFun: function clickFun() {
        this.updateState(false);
        this.target.selectAnswer(this.textTemp.optionNo);
    },
    textInit: function textInit(target, textTemp) {
        this.label.string = textTemp.optionContent;
        this.target = target;
        this.textTemp = textTemp;
    },
    updateState: function updateState(state) {
        var buttonCom = this.node.getComponent(cc.Button);
        buttonCom.interactable = state;
    }

});

cc._RF.pop();
},{}]},{},["dragOptionJS","ShowFeedback","OptionJS","PaoPaoJS","XingxingJS","GameJS","NetworkJS","NetworkJS_Data","config","textJs"])

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9zY3JpcHRzL0dhbWVKUy5qcyIsImFzc2V0cy9zY3JpcHRzL05ldHdvcmtKU19EYXRhLmpzIiwiYXNzZXRzL3NjcmlwdHMvTmV0d29ya0pTLmpzIiwiYXNzZXRzL2NvbXBvbmVudHMvT3B0aW9ucy9PcHRpb25KUy5qcyIsImFzc2V0cy9jb21wb25lbnRzL1Bhb3Bhby9QYW9QYW9KUy5qcyIsImFzc2V0cy9jb21wb25lbnRzL0ZlZWRiYWNrL1Nob3dGZWVkYmFjay5qcyIsImFzc2V0cy9jb21wb25lbnRzL1hpbmd4aW5nL1hpbmd4aW5nSlMuanMiLCJhc3NldHMvc2NyaXB0cy9jb25maWcuanMiLCJhc3NldHMvY29tcG9uZW50cy9EcmFnT3B0aW9ucy9kcmFnT3B0aW9uSlMuanMiLCJhc3NldHMvc2NyaXB0cy90ZXh0SnMuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHSjtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0E7O0FBRUE7QUFDSDtBQUNEO0FBQ0k7QUFDSTtBQUNIO0FBQ0Q7QUFDSTtBQUNIO0FBQ0Q7QUFDSDs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0o7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUxhOztBQVFqQjtBQUNIOztBQUVEO0FBQ0E7QUFDSTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNJO0FBQ0k7O0FBRUE7QUFDSDtBQUNHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNKO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNJO0FBQ0E7QUFDSDs7QUFFRDtBQUNIOztBQUVEO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0k7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7QUFDSjtBQUNHO0FBQ0g7QUFDRztBQUNIO0FBQ0o7QUFDRDtBQUNIOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0k7QUFDQTtBQUNJO0FBQ0g7QUFDRztBQUNIOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNKOztBQUVEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7QUFDRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNIO0FBQ0Q7QUFDSTtBQUNIO0FBQ0o7O0FBRUQ7QUFDQTtBQUNJO0FBQ0k7QUFDSDtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0g7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNJO0FBQ0g7QUFDSjtBQUNHO0FBQ0E7QUFDSTtBQUNIO0FBQ0o7QUFDSjs7QUFFRDtBQUNJO0FBQ0E7QUFDSDs7QUFuVEk7Ozs7Ozs7Ozs7QUNBVDs7QUFFQTtBQUNJOztBQUVBOztBQUdBO0FBQ0g7QUFDQztBQUNBO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Q7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNDO0FBQ0E7QUFFQTtBQUNBO0FBQ0Q7QUFDQTtBQUNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUGM7QUFTZjtBQUNBO0FBekNPOzs7Ozs7Ozs7O0FDRlQ7QUFDQzs7QUFFQTs7QUFHQTtBQUNBO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7O0FBRUQ7QUFDQzs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNDO0FBQ0E7O0FBRUQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUQ7QUFDQztBQUNDO0FBQ0E7O0FBRUQ7QUFDQTtBQUNBO0FBQ0M7QUFDQztBQUNDO0FBQ0E7QUFDQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNEO0FBQ0Q7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNEO0FBQ0Q7O0FBRUQ7QUFDQTtBQUNDOztBQUVBO0FBQ0M7QUFDQTs7QUFFQzs7QUFFQTtBQUNBO0FBQ0Q7QUFDQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRDtBQUNBO0FBQ0E7QUFDRDtBQUNEO0FBQ0E7QUFDQztBQUNBO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Q7QUFDQTtBQUNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0Q7QUFDQTs7QUFFRDtBQUNBO0FBQ0M7QUFDQTs7QUFFQTtBQUNBOztBQUVEO0FBQ0E7QUFDRTtBQUNEO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRDs7QUFFRDtBQUNBO0FBQ0U7QUFDRDtBQUNNO0FBQ0o7QUFDRjs7QUFFRDtBQUNBO0FBQ0M7O0FBRUE7O0FBRUM7QUFDRDtBQUNFO0FBQ0Y7QUFDRDtBQUNHO0FBQ0s7QUFDRDtBQUNBO0FBQ0U7QUFDTDs7QUF6Sm9COzs7Ozs7Ozs7O0FDQXpCO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBRlE7O0FBS1o7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNIOztBQUVEO0FBQ0k7QUFDQTtBQUNBO0FBQ0k7QUFDSDtBQUNKO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDSDtBQTFCSTs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQURROztBQUlaO0FBQ0E7QUFDSTtBQUNBO0FBQ0g7O0FBRUQ7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNJO0FBQ0E7QUFDSDtBQUNKO0FBckJJOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFMUTs7QUFRWjtBQUNJOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDSTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNIO0FBQ0c7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDSDtBQUNHO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0g7QUFDSjs7QUFFRDtBQUNJOztBQUVBO0FBQ0E7QUFDSDtBQWpESTs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7O0FBR0E7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQU9RO0FBQ0g7QUFFUjtBQXBCSTs7Ozs7Ozs7OztBQ0FUO0FBQ0E7O0FBRUE7QUFDQTtBQUNDO0FBQ0M7QUFDQTtBQUNBO0FBSE07QUFLUDs7QUFFRDtBQUNDO0FBQ0E7QUFDQTtBQUNEO0FBQ0E7QUFDQztBQUNBO0FBQ0E7QUFDQztBQUNBO0FBQ0Q7QUFDQTtBQUNDO0FBQ0E7O0FBRUQ7QUFDQTtBQUNEO0FBQ0E7QUFDQztBQUNBO0FBQ0E7QUFDRDtBQUNBO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7QUFDRDtBQUNBO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7QUFDRDs7OztBQUlBO0FBQ0k7QUFDSDtBQUNEOzs7OztBQUtBO0FBQ0M7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQztBQUNBO0FBQ0E7QUFDQTtBQUNEO0FBQ0E7QUFDRDs7Ozs7OztBQU9BO0FBQ0M7QUFDQTtBQUNBO0FBQ0M7QUFDQTtBQUNBO0FBQ0Q7QUFDQTtBQUNEO0FBQ0E7QUFFQztBQUNBO0FBQ0E7QUFFQztBQUNBO0FBRUM7QUFDQTtBQUNBO0FBQ0M7QUFDRDtBQUNEO0FBQ0Q7QUFDQTtBQUNEO0FBQ0E7QUFFQztBQUNBO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7QUFDRDs7QUFFQTtBQUNBOztBQUVEO0FBQ0M7QUFDQTs7QUFFRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUQ7QUFDQTtBQUNDO0FBQ0E7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNDO0FBQUE7QUFBQTtBQUdBO0FBQ0M7QUFDQTtBQUNEO0FBQ0M7QUFDQTtBQUNEO0FBQ0E7O0FBRUQ7QUFDQTtBQUNDO0FBQ0E7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQztBQUNBO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7QUFDRDtBQUNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0Q7QUFDQTtBQUNBOztBQUVEO0FBQ0E7QUFDQztBQUNBOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0M7QUFDQTtBQUNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0Q7QUFDQztBQUNBO0FBQ0E7QUFDQTtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFRDtBQUNBO0FBQ0U7QUFDRDtBQUNEOzs7Ozs7Ozs7O0FDNU5BO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBRlE7QUFJWjtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNIO0FBQ0c7QUFDQTtBQUNIO0FBQ0o7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNIO0FBQ0Q7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNIO0FBQ0o7QUFDRDtBQUNBO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNIO0FBOURJOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBRFE7O0FBSVo7QUFDQTtBQUdBO0FBQ0k7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ0k7QUFDQTtBQUNIOztBQXZCSSIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHRpbWVMYWJlbDogY2MuTGFiZWwsXG4gICAgICAgIHBhb3Bhb19ub2RlOiBjYy5Ob2RlLC8v5rOh5rOh6IOM5pmvXG4gICAgICAgIHBhb3Bhb19wcmVmOiBjYy5QcmVmYWIsLy/ms6Hms6HpooTliLZcbiAgICAgICAgZmVlZGJhY2tfbm9kZTogY2MuTm9kZSwvL+m+meiZvuWPjemmiFxuICAgICAgICBmZWVkYmFja19wcmVmOiBjYy5QcmVmYWIsLy/pvpnomb7pooTliLZcbiAgICAgICAgbG9zZVRpbWVfbm9kZTogY2MuTm9kZSwvL+WHj+aXtumXtFxuICAgICAgICBsb3NlVGltZTogMCwvL+WHj+aXtumXtDPnp5JcbiAgICAgICAgcXVlc3Rpb25UaXRsZTogY2MuTGFiZWwsLy8g6aKY5bmyXG4gICAgICAgIG9wdGlvbl9ub2RlOiBjYy5Ob2RlLC8vIOmAiemhuVxuICAgICAgICBvcHRpb25fbm9kZV9wcmVmOiBjYy5QcmVmYWIsLy9cbiAgICAgICAgcXVlc3Rpb25fbm9kZTogY2MuTm9kZSwvLyDpopjlubLlsI/kuYzpvp9cbiAgICAgICAgcXVlc3Rpb25fbm9kZV9wcmVmX3o6IGNjLlByZWZhYiwvL+mimOW5suWwj+S5jOm+nyjmraPluLgpXG4gICAgICAgIHF1ZXN0aW9uX25vZGVfcHJlZl9uOiBjYy5QcmVmYWIsLy/popjlubLlsI/kuYzpvp8o6Zq+6L+HKVxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgLy/ms6jlhoznm5HlkKxob21l6ZSu5LqL5Lu2XG4gICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3Jlc2lnbkFjdGl2ZVBhdXNlR2FtZScsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNjLmRpcmVjdG9yLnBhdXNlKCk7XG4gICAgICAgICAgICBjYy5nYW1lLnBhdXNlKCk7XG5cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdhcHAganVzdCByZXNpZ24gYWN0aXZlLicpO1xuICAgICAgICB9KTtcbiAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignYmVjb21lQWN0aXZlUmVzdW1lR2FtZScsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmIChjYy5nYW1lLmlzUGF1c2VkKSB7XG4gICAgICAgICAgICAgICAgY2MuZ2FtZS5yZXN1bWUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjYy5kaXJlY3Rvci5pc1BhdXNlZCkge1xuICAgICAgICAgICAgICAgIGNjLmRpcmVjdG9yLnJlc3VtZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc29sZS5sb2coJ2FwcCBqdXN0IGJlY29tZSBhY3RpdmUuJyk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8v5Yib5bu66b6Z6Jm+XG4gICAgICAgIHZhciBmZWVkYmFjayA9IGNjLmluc3RhbnRpYXRlKHRoaXMuZmVlZGJhY2tfcHJlZik7XG4gICAgICAgIHRoaXMuZmVlZGJhY2tfbm9kZS5hZGRDaGlsZChmZWVkYmFjayk7XG4gICAgICAgIC8vIOe8k+WGsuaxoFxuICAgICAgICB0aGlzLmFuc3dlckl0ZW1Qb29sID0gbmV3IGNjLk5vZGVQb29sKCk7XG4gICAgICAgIC8v5Y+N6aaIXG4gICAgICAgIHRoaXMuZmVlZGJhY2tKUyA9IGZlZWRiYWNrLmdldENvbXBvbmVudCgnU2hvd0ZlZWRiYWNrJyk7XG4gICAgICAgIC8v5rCU5rOhXG4gICAgICAgIHRoaXMuY3JlYXRlUGFvcGFvKCk7XG4gICAgICAgIC8v562U6aKY5pe26Ze0XG4gICAgICAgIHRoaXMuYW5zd2VyVGltZSA9IDA7XG4gICAgICAgIC8vJ0EvQi9DL0QnLOeUqOaIt+etlOahiOmAiemhuVxuICAgICAgICB0aGlzLmFuc3dlckNvbnRleHQgPSAnJztcbiAgICAgICAgLy/lgJLorqHml7ZcbiAgICAgICAgdGhpcy5jb3VudERvd24gPSAzO1xuICAgICAgICAvL+WAkuiuoeaXtuWbnuiwg1xuICAgICAgICB0aGlzLnRpbWVDYWxsYmFjayA9IHRoaXMudGltZUNhbGxiYWNrRnVuYygpO1xuICAgICAgICAvL+aYr+WQpuWcqOaYvuekuuWHj+aXtumXtFxuICAgICAgICB0aGlzLmlzU2hvd0xvc3NUaW1lID0gZmFsc2U7XG4gICAgICAgIC8v5b2T5YmN6aKY55uu5bqP5Y+3XG4gICAgICAgIHRoaXMubm93UXVlc3Rpb25JRCA9IDA7XG4gICAgICAgIC8v6aKY55uu5YiX6KGoXG4gICAgICAgIHRoaXMucXVlc3Rpb25BcnIgPSBbXTtcbiAgICAgICAgLy/mlLbpm4bmlbDmja5cbiAgICAgICAgdGhpcy5hbnN3ZXJJbmZvQXJyID0gW107XG4gICAgICAgIC8v6K+35rGC5pWw5o2uXG4gICAgICAgIHRoaXMubmV0d29yayA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoJ05ldHdvcmtKU19EYXRhJyk7XG4gICAgICAgIHRoaXMubmV0d29yay5zZW5kWEhSKHRoaXMpO1xuICAgICAgICBjb25zb2xlLmxvZyh0aGlzLm5ldHdvcmspO1xuICAgICAgICB0aGlzLnNwZWNpYWxXdWd1aSA9IG51bGw7XG4gICAgfSxcblxuICAgIC8v5Yqg6L295rOh5rOhXG4gICAgY3JlYXRlUGFvcGFvOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8v5bem6L65XG4gICAgICAgIGxldCB3aWR0aCA9IHRoaXMubm9kZS53aWR0aDtcbiAgICAgICAgbGV0IGhlaWdodCA9IDEwMTIuMDtcbiAgICAgICAgbGV0IHBhb3Bhb1ggPSBbMTIwLCA0MCwgMTYwLCA4MCwgMjAwXTtcbiAgICAgICAgbGV0IHBvc1kgPSBoZWlnaHQgLyAocGFvcGFvWC5sZW5ndGgpO1xuICAgICAgICBmb3IgKHZhciBpbmRleCA9IDA7IGluZGV4IDwgcGFvcGFvWC5sZW5ndGg7IGluZGV4KyspIHtcbiAgICAgICAgICAgIHZhciBwYW9wYW8gPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnBhb3Bhb19wcmVmKTtcbiAgICAgICAgICAgIHBhb3Bhby54ID0gcGFvcGFvWFtpbmRleF07XG4gICAgICAgICAgICBwYW9wYW8ueSA9IC0gcG9zWSAqIGluZGV4O1xuICAgICAgICAgICAgdGhpcy5wYW9wYW9fbm9kZS5hZGRDaGlsZChwYW9wYW8pO1xuICAgICAgICB9XG4gICAgICAgIC8v5Y+z6L65XG4gICAgICAgIGZvciAodmFyIGluZGV4ID0gMDsgaW5kZXggPCBwYW9wYW9YLmxlbmd0aDsgaW5kZXgrKykge1xuICAgICAgICAgICAgdmFyIHBhb3BhbyA9IGNjLmluc3RhbnRpYXRlKHRoaXMucGFvcGFvX3ByZWYpO1xuICAgICAgICAgICAgcGFvcGFvLnggPSB3aWR0aCAtIHBhb3Bhb1hbaW5kZXhdO1xuICAgICAgICAgICAgcGFvcGFvLnkgPSAtIHBvc1kgKiBpbmRleDtcbiAgICAgICAgICAgIHRoaXMucGFvcGFvX25vZGUuYWRkQ2hpbGQocGFvcGFvKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICAvLyBhbnN3ZXJJbmZvWydhbnN3ZXJUaW1lJ10gPSAn55So5pe25aSa5bCRJztcbiAgICAvLyBhbnN3ZXJJbmZvWydsZXZlTFF1ZXN0aW9uRGV0YWlsTnVtJ10gPSAnSVBT6aKY55uu77yI5bCP6aKY77yJ5bqP5Y+3JztcbiAgICAvLyBhbnN3ZXJJbmZvWydsZXZlbFF1ZXN0aW9uRGV0YWlsSUQnXSA9ICdJUFPpopjnm67vvIjlsI/popjvvIkgSUQnO1xuICAgIC8vIGFuc3dlckluZm9bJ2Fuc3dlclN0YXR1cyddID0gJ+etlOmimOeKtuaAgSAx77ya5q2j56GuIDLvvJrplJnor68nO1xuICAgIC8vIGFuc3dlckluZm9bJ2Fuc3dlckNvbnRleHQnXSA9ICdBL0IvQy9EJzsvL+eUqOaIt+etlOahiOmAiemhuVxuICAgIGNyZWF0ZUFuc3dlckluZm86IGZ1bmN0aW9uIChhbnN3ZXJTdGF0dXMpIHtcbiAgICAgICAgdmFyIHF1ZXN0aW9uID0gdGhpcy5xdWVzdGlvbkFyclt0aGlzLm5vd1F1ZXN0aW9uSURdO1xuICAgICAgICAvL+e7hOijheaVsOaNrlxuICAgICAgICB2YXIgYW5zd2VySW5mbyA9IHtcbiAgICAgICAgICAgIGFuc3dlclRpbWU6IHRoaXMuYW5zd2VyVGltZSxcbiAgICAgICAgICAgIGxldmVMUXVlc3Rpb25EZXRhaWxOdW06IHF1ZXN0aW9uLmxldmVMUXVlc3Rpb25EZXRhaWxOdW0sXG4gICAgICAgICAgICBsZXZlbFF1ZXN0aW9uRGV0YWlsSUQ6IHF1ZXN0aW9uLmxldmVsUXVlc3Rpb25EZXRhaWxJRCxcbiAgICAgICAgICAgIGFuc3dlclN0YXR1czogYW5zd2VyU3RhdHVzLFxuICAgICAgICAgICAgYW5zd2VyQ29udGV4dDogdGhpcy5hbnN3ZXJDb250ZXh0LFxuICAgICAgICB9O1xuXG4gICAgICAgIHRoaXMuYW5zd2VySW5mb0Fyci5wdXNoKGFuc3dlckluZm8pO1xuICAgIH0sXG5cbiAgICAvL+m+meiZvuWPjemmiFxuICAgIHNob3dGZWVkYmFjazogZnVuY3Rpb24gKHR5cGUpIHtcbiAgICAgICAgLy/pvpnomb7lj43ppohcbiAgICAgICAgdGhpcy5mZWVkYmFja0pTLnNob3dGZWVkYmFjayh0eXBlKTtcblxuICAgICAgICB0aGlzLm5vd1F1ZXN0aW9uSUQgKz0gMTtcbiAgICAgICAgLy/mmL7npLrov5vluqZcbiAgICAgICAgdGhpcy5uZXR3b3JrLmdhbWVMb2FkUHJvZ3Jlc3ModGhpcy5ub3dRdWVzdGlvbklELCB0aGlzLnF1ZXN0aW9uQXJyLmxlbmd0aCk7XG5cbiAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKHRoaXMubm93UXVlc3Rpb25JRCA+PSB0aGlzLnF1ZXN0aW9uQXJyLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIGlmIChDT05TT0xFX0xPR19PUEVOKSBjb25zb2xlLmxvZygn562U5a6M5LqGJyk7XG5cbiAgICAgICAgICAgICAgICB0aGlzLm5ldHdvcmsuZ2FtZU92ZXIodGhpcy5hbnN3ZXJJbmZvQXJyKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5mZWVkYmFja0pTLmFuaW1hdGlvblN0b3AoKTtcbiAgICAgICAgICAgICAgICAvL+enu+mZpOW9k+WJjeaJgOaciemAiemhuVxuICAgICAgICAgICAgICAgIHRoaXMuZGVsZXRlT3B0aW9uKCk7XG4gICAgICAgICAgICAgICAgLy/lvIDlp4vkuIvkuIDpophcbiAgICAgICAgICAgICAgICB0aGlzLnN0YXJ0bG9hZE9wdGlvbigpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LCAyLjApO1xuICAgIH0sXG5cbiAgICAvL+aYvuekuuWHj+aXtumXtFxuICAgIHNob3dMb3NzVGltZTogZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLmFuc3dlclRpbWUgKz0gdGhpcy5sb3NlVGltZTtcblxuICAgICAgICB0aGlzLmlzU2hvd0xvc3NUaW1lID0gdHJ1ZTtcbiAgICAgICAgLy/pgI/mmI7luqbmuJDlj5hcbiAgICAgICAgdGhpcy5sb3NlVGltZV9ub2RlLm9wYWNpdHkgPSAyNTU7XG5cbiAgICAgICAgdmFyIGNhbGxGdW5jID0gY2MuY2FsbEZ1bmMoZnVuY3Rpb24gKHRhcmdldCkge1xuICAgICAgICAgICAgdGhpcy5pc1Nob3dMb3NzVGltZSA9IGZhbHNlO1xuICAgICAgICAgICAgdGhpcy5sb3NlVGltZV9ub2RlLm9wYWNpdHkgPSAwO1xuICAgICAgICB9LCB0aGlzKTtcblxuICAgICAgICB0aGlzLmxvc2VUaW1lX25vZGUucnVuQWN0aW9uKGNjLnNlcXVlbmNlKGNjLmZhZGVUbygxLjAsIDApLCBjYWxsRnVuYykpO1xuICAgIH0sXG5cbiAgICAvL+WAkuiuoeaXtuWbnuiwg1xuICAgIHRpbWVDYWxsYmFja0Z1bmM6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIHRpbWVDYWxsYmFjayA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIC8v55So5oi3562U6aKY5pe26Ze0XG4gICAgICAgICAgICB0aGlzLmFuc3dlclRpbWUgKz0gMTtcbiAgICAgICAgICAgIC8v5YCS6K6h5pe25qyh5pWwXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlVGltZSArPSAxO1xuXG4gICAgICAgICAgICB2YXIgdGltZVN0cmluZyA9IHRoaXMuY291bnREb3duIC0gdGhpcy5hbnN3ZXJUaW1lO1xuXG4gICAgICAgICAgICBpZiAodGltZVN0cmluZyA8PSAwKSB7XG4gICAgICAgICAgICAgICAgLy/ml7bpl7TliLBcbiAgICAgICAgICAgICAgICBpZiAoQ09OU09MRV9MT0dfT1BFTikgY29uc29sZS5sb2coJ+aXtumXtOWIsCcpO1xuXG4gICAgICAgICAgICAgICAgdGhpcy5pc1Nob3dGZWVkID0gdHJ1ZTtcblxuICAgICAgICAgICAgICAgIHRoaXMuYW5zd2VyVGltZSA9IHRoaXMuY291bnREb3duO1xuICAgICAgICAgICAgICAgIHRoaXMudGltZUxhYmVsLnN0cmluZyA9ICcwMDowMCc7XG5cbiAgICAgICAgICAgICAgICB0aGlzLmNyZWF0ZUFuc3dlckluZm8oJzInKTtcblxuICAgICAgICAgICAgICAgIHRoaXMuc2hvd0ZlZWRiYWNrKDMpO1xuXG4gICAgICAgICAgICAgICAgLy/mmK/lh4/ml7bpl7TvvIzlj5bmtojlrprml7blmags5pS+5Zyoc2hvd0ZlZWRiYWNr77yM6KaB5LiN54S25Lya5LiN5omn6KGMc2NoZWR1bGVPbmNlXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuYW5zd2VyVGltZSA+IHRoaXMuc2NoZWR1bGVUaW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIC8v5Y+W5raI5a6a5pe25ZmoXG4gICAgICAgICAgICAgICAgICAgIHRoaXMudW5zY2hlZHVsZSh0aGlzLnRpbWVDYWxsYmFjayk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmICh0aW1lU3RyaW5nIDwgMTApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRpbWVMYWJlbC5zdHJpbmcgPSAnMDA6MCcgKyB0aW1lU3RyaW5nO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRpbWVMYWJlbC5zdHJpbmcgPSAnMDA6JyArIHRpbWVTdHJpbmc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRpbWVDYWxsYmFjaztcbiAgICB9LFxuXG4gICAgLy/mmL7npLrlgJLorqHml7ZcbiAgICBzaG93U2NoZWR1bGU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5zY2hlZHVsZVRpbWUgPSAwO1xuICAgICAgICB0aGlzLnNjaGVkdWxlKHRoaXMudGltZUNhbGxiYWNrLCAxLjAsIHRoaXMuY291bnREb3duIC0gMSk7XG4gICAgfSxcblxuICAgIC8v56e76Zmk5b2T5YmN5omA5pyJ6YCJ6aG5XG4gICAgZGVsZXRlT3B0aW9uOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBhcnJheSA9IHRoaXMub3B0aW9uX25vZGUuY2hpbGRyZW47XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYXJyYXkubGVuZ3RoOykge1xuICAgICAgICAgICAgdmFyIHRlbXBPcHRpb24gPSBhcnJheVtpXTtcbiAgICAgICAgICAgIC8v5pS+6L+b5a+56LGh5rGg5Lya6Ieq5Yqo6LCD55SocmVtb3ZlRnJvbVBhcmVudFxuICAgICAgICAgICAgdGhpcy5hbnN3ZXJJdGVtUG9vbC5wdXQodGVtcE9wdGlvbik7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgLy/pgInpobnmjInpkq7kuI3lj6/nlKhcbiAgICBjaGFuZ2VPcHRpb25FbmFibGU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgLy/mmoLlgZzlvZPliY3oioLngrnkuIrms6jlhoznmoTmiYDmnInoioLngrnns7vnu5/kuovku7bvvIzoioLngrnns7vnu5/kuovku7bljIXlkKvop6bmkbjlkozpvKDmoIfkuovku7bjgIJcbiAgICAgICAgdGhpcy5vcHRpb25fbm9kZS5wYXVzZVN5c3RlbUV2ZW50cyh0cnVlKTtcbiAgICB9LFxuXG4gICAgLy/liJvlu7rpgInpobnmjInpkq5cbiAgICBjcmVhdGVPcHRpb246IGZ1bmN0aW9uIChxdWVzdGlvbk9wdGlvbnMpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBxdWVzdGlvbk9wdGlvbnMubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgIHZhciBvcHRpb25JdGVtID0gbnVsbDtcbiAgICAgICAgICAgIGlmICh0aGlzLmFuc3dlckl0ZW1Qb29sLnNpemUoKSA+IDApIHtcbiAgICAgICAgICAgICAgICBvcHRpb25JdGVtID0gdGhpcy5hbnN3ZXJJdGVtUG9vbC5nZXQoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgb3B0aW9uSXRlbSA9IGNjLmluc3RhbnRpYXRlKHRoaXMub3B0aW9uX25vZGVfcHJlZik7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHZhciBvcHRpb25KUyA9IG9wdGlvbkl0ZW0uZ2V0Q29tcG9uZW50KCd0ZXh0SnMnKTtcbiAgICAgICAgICAgIG9wdGlvbkpTLnRleHRJbml0KHRoaXMsIHF1ZXN0aW9uT3B0aW9uc1tpXSk7XG4gICAgICAgICAgICAvL+aMiemSruWPr+eUqFxuICAgICAgICAgICAgb3B0aW9uSlMudXBkYXRlU3RhdGUodHJ1ZSk7XG4gICAgICAgICAgICB0aGlzLm9wdGlvbl9ub2RlLmFkZENoaWxkKG9wdGlvbkl0ZW0pO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIC8v5Yib5bu65bCP5LmM6b6fXG4gICAgY3JlYXRlV3VndWk6IGZ1bmN0aW9uIChxdWVzdGlvbkNvbnRlbnQpIHtcbiAgICAgICAgdGhpcy5xdWVzdGlvbl9ub2RlLnJlbW92ZUFsbENoaWxkcmVuKCk7XG4gICAgICAgIHZhciB0aW1lVGVtcCA9IDAuMjtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBxdWVzdGlvbkNvbnRlbnQubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgICAgIHZhciBvcHRpb25JdGVtID0gbnVsbDtcbiAgICAgICAgICAgIGlmIChxdWVzdGlvbkNvbnRlbnRbaV0gPT0gJyonKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zcGVjaWFsV3VndWkgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnF1ZXN0aW9uX25vZGVfcHJlZl9uKTtcbiAgICAgICAgICAgICAgICB0aGlzLnF1ZXN0aW9uX25vZGUuYWRkQ2hpbGQodGhpcy5zcGVjaWFsV3VndWkpO1xuICAgICAgICAgICAgICAgIHRoaXMuc3BlY2lhbFd1Z3VpLnJ1bkFjdGlvbihjYy5tb3ZlVG8odGltZVRlbXAsY2MucCgwLDApKSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIG9wdGlvbkl0ZW0gPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnF1ZXN0aW9uX25vZGVfcHJlZl96KTtcbiAgICAgICAgICAgICAgICB2YXIgbGFiZWwgPSBvcHRpb25JdGVtLmdldENoaWxkQnlOYW1lKCdodWFuZ3FpcWl1JykuZ2V0Q2hpbGRCeU5hbWUoJ2xhYmVsJyk7XG4gICAgICAgICAgICAgICAgbGFiZWwuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBxdWVzdGlvbkNvbnRlbnRbaV07XG4gICAgICAgICAgICAgICAgdGhpcy5xdWVzdGlvbl9ub2RlLmFkZENoaWxkKG9wdGlvbkl0ZW0pO1xuICAgICAgICAgICAgICAgIG9wdGlvbkl0ZW0ucnVuQWN0aW9uKGNjLm1vdmVUbyh0aW1lVGVtcCxjYy5wKDAsMCkpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRpbWVUZW1wICs9IDAuMjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB0aGlzLm9wdGlvbl9ub2RlLnJlc3VtZVN5c3RlbUV2ZW50cyh0cnVlKTtcbiAgICAgICAgfSwgMC4yKnF1ZXN0aW9uQ29udGVudC5sZW5ndGgpO1xuICAgIH0sXG5cbiAgICAvL+W8gOWni+WKoOi9vemAiemhuVxuICAgIHN0YXJ0bG9hZE9wdGlvbjogZnVuY3Rpb24gKCkge1xuICAgICAgICBmdW5jdGlvbiBkZWxldGVIdG1sKHRleHQpIHtcbiAgICAgICAgICAgIHJldHVybiB0ZXh0LnJlcGxhY2UoLzxbXj5dKz4vZywgXCJcIik7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHF1ZXN0aW9uID0gdGhpcy5xdWVzdGlvbkFyclt0aGlzLm5vd1F1ZXN0aW9uSURdO1xuICAgICAgICAvL+WAkuiuoeaXtlxuICAgICAgICB2YXIgY291bnREb3duID0gcGFyc2VJbnQocXVlc3Rpb24uaW50ZXJhY3RpdmVKc29uWydjb3VudERvd24nXSk7XG4gICAgICAgIHRoaXMuY291bnREb3duID0gY291bnREb3duO1xuICAgICAgICB0aGlzLnRpbWVMYWJlbC5zdHJpbmcgPSAnMDA6JyArIHRoaXMuY291bnREb3duO1xuICAgICAgICB0aGlzLnF1ZXN0aW9uVGl0bGUuc3RyaW5nID0gJyc7XG4gICAgICAgIHRoaXMucXVlc3Rpb25UaXRsZS5zdHJpbmcgPSBkZWxldGVIdG1sKHF1ZXN0aW9uLnFlc2NvbnQpO1xuICAgICAgICB0aGlzLnJpZ2h0QW5zd2VyID0gcXVlc3Rpb24ucXVlc3Rpb25Db3JyZWN0O1xuICAgICAgICB0aGlzLmFuc3dlclRpbWUgPSAwO1xuICAgICAgICB0aGlzLnNob3dTY2hlZHVsZSgpO1xuICAgICAgICB0aGlzLmlzU2hvd0ZlZWQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5jcmVhdGVPcHRpb24ocXVlc3Rpb24ucXVlc3Rpb25PcHRpb25zKTtcbiAgICAgICAgdGhpcy5jaGFuZ2VPcHRpb25FbmFibGUoKTtcbiAgICAgICAgdGhpcy5jcmVhdGVXdWd1aShxdWVzdGlvbi5pbnRlcmFjdGl2ZUpzb25bJ3F1ZXN0aW9uQ29udGVudCddKTtcbiAgICB9LFxuXG4gICAgLy/popjnm67kuIvovb3lrozmiJDvvIzlvIDlp4vmuLjmiI9cbiAgICBzdGFydExvYWRHYW1lOiBmdW5jdGlvbiAocXVlc3Rpb25BcnIpIHtcbiAgICAgICAgdGhpcy5xdWVzdGlvbkFyciA9IHF1ZXN0aW9uQXJyO1xuICAgICAgICAvL+W8gOWni+WKoOi9vemimOebrlxuICAgICAgICB0aGlzLnN0YXJ0bG9hZE9wdGlvbigpO1xuICAgIH0sXG5cbiAgICAvL+mAieS4reetlOahiFxuICAgIHNlbGVjdEFuc3dlcjogZnVuY3Rpb24gKG9wdGlvbk5vKSB7XG4gICAgICAgIHRoaXMuY2hhbmdlT3B0aW9uRW5hYmxlKCk7XG4gICAgICAgIC8v5pi+56S654q25oCB6L+H56iL5Lit5LiN5o6l5pS25LqL5Lu2XG4gICAgICAgIGlmICh0aGlzLmlzU2hvd0ZlZWQgfHwgdGhpcy5pc1Nob3dMb3NzVGltZSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8v5Y+W5raI5a6a5pe25ZmoXG4gICAgICAgIHRoaXMudW5zY2hlZHVsZSh0aGlzLnRpbWVDYWxsYmFjayk7XG4gICAgICAgIHRoaXMuaXNTaG93RmVlZCA9IHRydWU7XG4gICAgICAgIHRoaXMuYW5zd2VyQ29udGV4dCA9IG9wdGlvbk5vO1xuICAgICAgICBpZiAob3B0aW9uTm8gPT0gdGhpcy5yaWdodEFuc3dlcikge1xuICAgICAgICAgICAgdGhpcy5jcmVhdGVBbnN3ZXJJbmZvKCcxJyk7XG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zaG93RmVlZGJhY2soMSk7XG4gICAgICAgICAgICB9LCAwLjEpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5jcmVhdGVBbnN3ZXJJbmZvKCcyJyk7XG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zaG93RmVlZGJhY2soMik7XG4gICAgICAgICAgICB9LCAwLjEpO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIG9uRGVzdHJveTogZnVuY3Rpb24gKCkge1xuICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdyZXNpZ25BY3RpdmVQYXVzZUdhbWUnKTtcbiAgICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignYmVjb21lQWN0aXZlUmVzdW1lR2FtZScpO1xuICAgIH0sXG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxufSk7IiwidmFyIE5ldHdvcmtKUyA9IHJlcXVpcmUoXCJOZXR3b3JrSlNcIik7XG5cbmNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBOZXR3b3JrSlMsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG5cdH0sXG5cbiAgICAvL+ino+aekOi9rOaNouavj+S4gOadoeaVsOaNrlxuXHRhbmFseXNpc0RpY3Q6IGZ1bmN0aW9uIChxdWVzdGlvbkRpY3QpIHtcblx0XHR2YXIgaW50ZXJhY3RpdmVKc29uID0gcXVlc3Rpb25EaWN0LmludGVyYWN0aXZlSnNvbjtcblx0XHRpZiAoIWludGVyYWN0aXZlSnNvbiB8fCBpbnRlcmFjdGl2ZUpzb24ubGVuZ3RoID09IDApIHtcblx0XHRcdC8v5a656ZSZ5LiN5b2VanNvbueahOaDheWGtVxuXHRcdFx0dGhpcy5nYW1lTG9hZEZhaWxlZCgyKTtcblx0XHRcdHJldHVybjtcblx0XHR9IGVsc2UgaWYgKHR5cGVvZiBpbnRlcmFjdGl2ZUpzb24gPT0gJ3N0cmluZycpIHtcblx0XHRcdGludGVyYWN0aXZlSnNvbiA9IEpTT04ucGFyc2UoaW50ZXJhY3RpdmVKc29uKTtcblx0XHR9XG5cdFx0dmFyIG9wdGlvbmFuZGFuc3dlciA9IHF1ZXN0aW9uRGljdC5vcHRpb25hbmRhbnN3ZXJzWzBdO1xuXG5cdFx0dmFyIG9wdGlvbnMgPSBvcHRpb25hbmRhbnN3ZXIub3B0aW9ucztcblxuXHRcdHZhciBvcHRpb25zQXJyID0gW107XG5cdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBvcHRpb25zLmxlbmd0aDsgKytpKSB7XG5cdFx0dmFyIG9wdGlvbiA9IG9wdGlvbnNbaV07XG5cdFx0dmFyIG9wdGlvbmNvbnRlbnQgPSBvcHRpb24ub3B0aW9uY29udGVudDtcblx0XHR2YXIgdGVtcCA9IHtcblx0XHRcdG9wdGlvbk5vOiBvcHRpb24ub3B0aW9ubm8sLy/pgInpoblcblx0XHRcdG9wdGlvbkNvbnRlbnQ6IHRoaXMucmVtb3ZlU3BhbihvcHRpb25jb250ZW50KSwvL+mAiemhueetlOahiFxuXHRcdH07XG5cdFx0XHRvcHRpb25zQXJyLnB1c2godGVtcCk7XG5cdFx0fVxuXHRcdC8v5q+P5LiA6YGT5bCP6aKY5YaF5a65XG5cdFx0dmFyIHF1ZXN0aW9uID0ge1xuXHRcdFx0YW5zd2VyVGltZTogJzAnLC8v562U6aKY5pe26Ze0XG5cdFx0XHRsZXZlbFF1ZXN0aW9uRGV0YWlsSUQ6IHF1ZXN0aW9uRGljdC5xdWVzdGlvbmlkLC8vSVBT6aKY55uu77yI5bCP6aKY77yJIElEXG5cdFx0XHRsZXZlTFF1ZXN0aW9uRGV0YWlsTnVtOiBxdWVzdGlvbkRpY3Qub3JkZXJpZCwvL0lQU+mimOebru+8iOWwj+mimO+8ieW6j+WPt1xuXHRcdFx0cWVzY29udDogdGhpcy5yZW1vdmVTcGFuKHF1ZXN0aW9uRGljdC5xZXNjb250KSwvL+mimOW5slxuXHRcdFx0aW50ZXJhY3RpdmVKc29uOiBpbnRlcmFjdGl2ZUpzb24sLy/moLzlpJbphY3nva5qc29uXG5cdFx0XHRxdWVzdGlvbk9wdGlvbnM6IG9wdGlvbnNBcnIsLy8g6aKY5bmy6YCJ6aG5XG5cdFx0XHRxdWVzdGlvbkNvcnJlY3Q6IHRoaXMucmVtb3ZlU3BhbihvcHRpb25hbmRhbnN3ZXIucmlnaHRhbnN3ZXIpLFxuXHRcdH07XG5cdFx0cmV0dXJuIHF1ZXN0aW9uO1xuXHR9LFxufSk7XG4iLCJ2YXIgTmV0d29ya0pTID0gY2MuQ2xhc3Moe1xuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cblx0cHJvcGVydGllczoge1xuXHR9LFxuXG5cdC8v6Kej5p6QdXJs5Y+C5pWwXG5cdEdldFF1ZXJ5U3RyaW5nOiBmdW5jdGlvbiAobmFtZSkge1xuXHRcdHZhciByZWcgPSBuZXcgUmVnRXhwKFwiKF58JilcIiArIG5hbWUgKyBcIj0oW14mXSopKCZ8JClcIik7XG5cdFx0dmFyIHIgPSB3aW5kb3cubG9jYXRpb24uc2VhcmNoLnN1YnN0cigxKS5tYXRjaChyZWcpO1xuXHRcdGlmIChyICE9IG51bGwpIHJldHVybiBkZWNvZGVVUkkoclsyXSk7IHJldHVybiBudWxsO1xuXHR9LFxuXG5cdHNlbmRYSFI6IGZ1bmN0aW9uIChyYWNpbmdqcykge1xuXHRcdHRoaXMucmFjaW5nanMgPSByYWNpbmdqcztcblxuXHRcdHZhciB4aHIgPSBjYy5sb2FkZXIuZ2V0WE1MSHR0cFJlcXVlc3QoKTtcblx0XHR0aGlzLnN0cmVhbVhIUkV2ZW50c1RvTGFiZWwoeGhyLCAnR0VUJyk7XG5cblx0XHQvL+mimOW6k1xuXHRcdHZhciBmaWxlVXJsID0gdGhpcy5HZXRRdWVyeVN0cmluZygnZmlsZVVybCcpO1xuXHRcdHhoci5vcGVuKFwiR0VUXCIsIGZpbGVVcmwpO1xuXG5cdFx0aWYgKGNjLnN5cy5pc05hdGl2ZSkge1xuXHRcdFx0eGhyLnNldFJlcXVlc3RIZWFkZXIoXCJBY2NlcHQtRW5jb2RpbmdcIiwgXCJnemlwLGRlZmxhdGVcIik7XG5cdFx0fVxuXG5cdFx0Ly8gbm90ZTogSW4gSW50ZXJuZXQgRXhwbG9yZXIsIHRoZSB0aW1lb3V0IHByb3BlcnR5IG1heSBiZSBzZXQgb25seSBhZnRlciBjYWxsaW5nIHRoZSBvcGVuKClcblx0XHQvLyBtZXRob2QgYW5kIGJlZm9yZSBjYWxsaW5nIHRoZSBzZW5kKCkgbWV0aG9kLlxuXHRcdHhoci50aW1lb3V0ID0gNjAwMDA7Ly90aW1lb3V0XG5cblx0XHR4aHIuc2VuZCgpO1xuXHR9LFxuXG5cdHN0cmVhbVhIUkV2ZW50c1RvTGFiZWw6IGZ1bmN0aW9uICh4aHIsIG1ldGhvZCwgcmVzcG9uc2VIYW5kbGVyKSB7XG5cdFx0dmFyIGhhbmRsZXIgPSByZXNwb25zZUhhbmRsZXIgfHwgZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG5cdFx0XHRyZXR1cm4gbWV0aG9kICsgXCIgUmVzcG9uc2U6IFwiICsgcmVzcG9uc2Uuc3Vic3RyaW5nKDAsIDMwKSArICcuLi4nO1xuXHRcdH07XG5cblx0XHR2YXIgc2VsZiA9IHRoaXM7XG5cdFx0Ly8gU3BlY2lhbCBldmVudFxuXHRcdHhoci5vbnJlYWR5c3RhdGVjaGFuZ2UgPSBmdW5jdGlvbiAoKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRpZiAoeGhyLnJlYWR5U3RhdGUgPT09IFhNTEh0dHBSZXF1ZXN0LkRPTkUpIHtcblx0XHRcdFx0XHRpZiAoQ09OU09MRV9MT0dfT1BFTikgY29uc29sZS5sb2coaGFuZGxlcih4aHIucmVzcG9uc2VUZXh0KSk7XG5cdFx0XHRcdFx0aWYgKHhoci5zdGF0dXMgPT09IDIwMCkge1xuXHRcdFx0XHRcdFx0Ly8gc2VsZi5oaWRlUHJvZ3Jlc3NCYXIoKTtcblx0XHRcdFx0XHRcdHNlbGYuYW5hbHlzaXNEYXRhKHhoci5yZXNwb25zZVRleHQpO1xuXHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRpZiAoQ09OU09MRV9MT0dfT1BFTikgY29uc29sZS5sb2coJ1RoZXJlIHdhcyBhIHByb2JsZW0gd2l0aCB0aGUgcmVxdWVzdC4nKTtcblx0XHRcdFx0XHRcdC8v5LiL6L295aSx6LSl5Y+N6aaI57uT5p6cXG5cdFx0XHRcdFx0XHRzZWxmLmdhbWVMb2FkRmFpbGVkKDEpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0Y2F0Y2ggKGUpIHtcblx0XHRcdFx0aWYgKENPTlNPTEVfTE9HX09QRU4pIGNvbnNvbGUubG9nKCdDYXVnaHQgRXhjZXB0aW9uOiAnICsgZS5kZXNjcmlwdGlvbik7XG5cdFx0XHRcdC8v5LiL6L295aSx6LSl5Y+N6aaI57uT5p6cXG5cdFx0XHRcdHNlbGYuZ2FtZUxvYWRGYWlsZWQoMSk7XG5cdFx0XHR9XG5cdFx0fTtcblx0fSxcblxuXHQvL+ino+aekOaVsOaNrlxuXHRhbmFseXNpc0RhdGE6IGZ1bmN0aW9uIChyZXNwb25zZVRleHQpIHtcblx0XHR2YXIgcXVlc3Rpb25zID0gSlNPTi5wYXJzZShyZXNwb25zZVRleHQpO1xuXHRcdFxuXHRcdGlmIChxdWVzdGlvbnMgfHwgcXVlc3Rpb25zLmxlbmd0aCA+IDApIHtcblx0XHRcdHZhciBxdWVzdGlvbkFyciA9IFtdO1xuXHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBxdWVzdGlvbnMubGVuZ3RoOyArK2kpIHtcblxuXHRcdFx0XHR2YXIgcXVlc3Rpb24gPSB0aGlzLmFuYWx5c2lzRGljdChxdWVzdGlvbnNbaV0pO1xuXG5cdFx0XHRcdHF1ZXN0aW9uQXJyLnB1c2gocXVlc3Rpb24pO1xuXHRcdFx0fVxuXHRcdFx0aWYgKHF1ZXN0aW9uQXJyICYmIHF1ZXN0aW9uQXJyLmxlbmd0aCA+IDApIHtcblx0XHRcdFx0dGhpcy5yYWNpbmdqcy5zdGFydExvYWRHYW1lKHF1ZXN0aW9uQXJyKTtcblx0XHRcdFx0Ly/pgJrnn6XmuLjmiI/liqDovb3miJDlip/vvIzlvIDlp4vmuLjmiI9cblx0XHRcdFx0dGhpcy5nYW1lTG9hZFN1Y2Nlc3MocXVlc3Rpb25BcnIubGVuZ3RoKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHRoaXMuZ2FtZUxvYWRGYWlsZWQoMik7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIHtcblx0XHRcdHRoaXMuZ2FtZUxvYWRGYWlsZWQoMik7XG5cdFx0fVxuXHR9LFxuXHQvL+ino+aekOi9rOaNouavj+S4gOadoeaVsOaNrlxuXHRhbmFseXNpc0RpY3Q6IGZ1bmN0aW9uIChxdWVzdGlvbkRpY3QpIHtcblx0XHR2YXIgaW50ZXJhY3RpdmVKc29uID0gcXVlc3Rpb25EaWN0LmludGVyYWN0aXZlSnNvbjtcblx0XHRpZiAoIWludGVyYWN0aXZlSnNvbiB8fCBpbnRlcmFjdGl2ZUpzb24ubGVuZ3RoID09IDApIHtcblx0XHRcdC8v5a656ZSZ5LiN5b2VanNvbueahOaDheWGtVxuXHRcdFx0dGhpcy5nYW1lTG9hZEZhaWxlZCgyKTtcblx0XHRcdHJldHVybjtcblx0XHR9IGVsc2UgaWYgKHR5cGVvZiBpbnRlcmFjdGl2ZUpzb24gPT0gJ3N0cmluZycpIHtcblx0XHRcdGludGVyYWN0aXZlSnNvbiA9IEpTT04ucGFyc2UoaW50ZXJhY3RpdmVKc29uKTtcblx0XHR9XG5cdFx0Ly/mr4/kuIDpgZPlsI/popjlhoXlrrlcblx0XHR2YXIgcXVlc3Rpb24gPSB7XG5cdFx0XHRhbnN3ZXJUaW1lOiAnMCcsLy/nrZTpopjml7bpl7Rcblx0XHRcdGxldmVsUXVlc3Rpb25EZXRhaWxJRDogcXVlc3Rpb25EaWN0LnF1ZXN0aW9uaWQsLy9JUFPpopjnm67vvIjlsI/popjvvIkgSURcblx0XHRcdGxldmVMUXVlc3Rpb25EZXRhaWxOdW06IHF1ZXN0aW9uRGljdC5vcmRlcmlkLC8vSVBT6aKY55uu77yI5bCP6aKY77yJ5bqP5Y+3XG5cdFx0XHRxZXNjb250OiB0aGlzLnJlbW92ZVNwYW4ocXVlc3Rpb25EaWN0LnFlc2NvbnQpLC8v6aKY5bmyXG5cdFx0XHRpbnRlcmFjdGl2ZUpzb246IGludGVyYWN0aXZlSnNvbiwvL+agvOWklumFjee9rmpzb25cblx0XHR9O1xuXG5cdFx0cmV0dXJuIHF1ZXN0aW9uO1xuXHR9LFxuXG5cdC8v6L+H5ruk5qCH562+XG5cdHJlbW92ZVNwYW46IGZ1bmN0aW9uIChzcGFuU3RyaW5nKSB7XG5cdFx0dmFyIG5ld1N0ciA9IHNwYW5TdHJpbmcucmVwbGFjZSgnPHNwYW4+JywgJycpO1xuXHRcdG5ld1N0ciA9IG5ld1N0ci5yZXBsYWNlKCc8L3NwYW4+JywgJycpO1xuXG5cdFx0cmV0dXJuIG5ld1N0cjtcblx0fSxcblxuXHQvL+S4i+i9veino+aekOWksei0pXR5cGU6MS7kuIvovb3lpLHotKXvvIwyLuino+aekOWksei0pVxuXHRnYW1lTG9hZEZhaWxlZDogZnVuY3Rpb24gKHR5cGUpIHtcblx0XHQgaWYgKCFDT05TT0xFX0xPR19PUEVOKSB7XG5cdFx0aWYgKHR5cGUgPT0gMSkge1xuXHRcdFx0dmFyIHBhcmFtcyA9IGVuY29kZVVSSSgnZXJyY29kZT0xMDAwMSZlcnJtc2c95LiL6L295aSx6LSlJyk7XG5cdFx0XHQvL3dpbmRvdy5sb2NhdGlvbi5ocmVmID0gJ29wdGlvbkJsYW5rOi8vZ2FtZUxvYWRGYWlsZWQ/JyArIHBhcmFtcztcblx0XHR9IGVsc2Uge1xuXHRcdFx0dmFyIHBhcmFtcyA9IGVuY29kZVVSSSgnZXJyY29kZT0xMDAwMiZlcnJtc2c96Kej5p6Q5aSx6LSlJyk7XG5cdFx0XHQvL3dpbmRvdy5sb2NhdGlvbi5ocmVmID0gJ29wdGlvbkJsYW5rOi8vZ2FtZUxvYWRGYWlsZWQ/JyArIHBhcmFtcztcblx0XHR9XG5cdFx0fVxuXHR9LFxuXG5cdC8v6YCa55+l5ri45oiP5Yqg6L295oiQ5Yqf77yM5byA5aeL5ri45oiPXG5cdGdhbWVMb2FkU3VjY2VzczogZnVuY3Rpb24gKHRvdGFsTnVtYmVyKSB7XG5cdFx0IGlmICghQ09OU09MRV9MT0dfT1BFTikge1xuXHRcdHZhciBwYXJhbXMgPSBlbmNvZGVVUkkoJ3RvdGFsTnVtYmVyPScgKyB0b3RhbE51bWJlcik7XG7CoMKgwqDCoMKgwqDCoMKgLy93aW5kb3cubG9jYXRpb24uaHJlZiA9ICdvcHRpb25CbGFuazovL2dhbWVMb2FkU3VjY2Vzcz8nICsgcGFyYW1zO1xuXHRcdCB9XG5cdH0sXG5cblx0Ly/pgJrnn6XmuLjmiI/nu5PmnZ9cblx0Z2FtZU92ZXI6IGZ1bmN0aW9uIChhbnN3ZXJJbmZvQXJyKSB7XG5cdFx0dmFyIGRhdGEgPSBlbmNvZGVVUkkoSlNPTi5zdHJpbmdpZnkoYW5zd2VySW5mb0FycikpO1xuXG5cdFx0aWYgKENPTlNPTEVfTE9HX09QRU4pIGNvbnNvbGUubG9nKCdkYXRhSnNvbj0nICsgSlNPTi5zdHJpbmdpZnkoYW5zd2VySW5mb0FycikpO1xuXG5cdFx0IGlmICghQ09OU09MRV9MT0dfT1BFTikge1xuXHRcdC8vd2luZG93LmxvY2F0aW9uLmhyZWYgPSAnb3B0aW9uQmxhbms6Ly9nYW1lT3Zlcj9zdGF0dXM9MSZkYXRhPScgKyBkYXRhO1xuXHRcdCB9XG5cdH0sXG5cdC8v6YCa55+l5ri45oiP5Yqg6L295oiQ5Yqf77yM5byA5aeL5ri45oiPXG7CoMKgwqDCoGdhbWVMb2FkUHJvZ3Jlc3M6IGZ1bmN0aW9uIChub3dOdW1iZXIsIHRvdGFsTnVtYmVyKSB7XG7CoMKgwqDCoMKgwqDCoMKgIGlmICghQ09OU09MRV9MT0dfT1BFTikge1xuwqDCoMKgwqDCoMKgwqDCoHZhciBwYXJhbXMgPSBlbmNvZGVVUkkoJ25vd051bWJlcj0nICsgbm93TnVtYmVyICsgJyZ0b3RhbE51bWJlcj0nICsgdG90YWxOdW1iZXIpO1xuwqDCoMKgwqDCoMKgwqDCoC8vd2luZG93LmxvY2F0aW9uLmhyZWYgPSAnb3B0aW9uQmxhbms6Ly9nYW1lTG9hZFByb2dyZXNzPycgKyBwYXJhbXM7XG7CoMKgwqDCoMKgwqDCoMKgIH1cbsKgwqDCoMKgfSxcblxuXHRcbn0pOyIsImNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIG9wdGlvbl9ub2RlOiBjYy5Ob2RlLFxuICAgICAgICBsYWJlbDogY2MuTGFiZWxcbiAgICB9LFxuXG4gICAgaW5pdDogZnVuY3Rpb24gKGdhbWVKUywgb3B0aW9uLCBvcHRpb25MZW5ndGgpIHtcbiAgICAgICAgdGhpcy5nYW1lSlMgPSBnYW1lSlM7XG4gICAgICAgIHRoaXMub3B0aW9uID0gb3B0aW9uOy8v6YCJ6aG577yI6YCJ6aG577yM6YCJ6aG5562U5qGI77yJXG4gICAgICAgIHRoaXMubGFiZWwuc3RyaW5nID0gb3B0aW9uLm9wdGlvbkNvbnRlbnQ7Ly/or7vlj5bpgInpobnnrZTmoYhcbiAgICAgICAgdGhpcy5vcHRpb25ObyA9IG9wdGlvbi5vcHRpb25ObztcbiAgICB9LFxuXG4gICAgb3B0aW9uQ2xpY2s6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICBzZWxmLnVwZGF0ZVN0YXRlKGZhbHNlKTtcbiAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgc2VsZi5nYW1lSlMuc2VsZWN0QW5zd2VyKHNlbGYub3B0aW9uKTtcbiAgICAgICAgfSwgMC4yKTtcbiAgICB9LFxuICAgIC8v5oyJ6ZKu5piv5ZCm5Y+v54K55Ye7XG4gICAgdXBkYXRlU3RhdGU6IGZ1bmN0aW9uIChpbnRlcmFjdGFibGUpIHtcbiAgICAgICAgdmFyIGJ1dHRvbkNvbSA9IHRoaXMub3B0aW9uX25vZGUuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG4gICAgICAgIGJ1dHRvbkNvbS5pbnRlcmFjdGFibGUgPSBpbnRlcmFjdGFibGU7XG4gICAgfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgcGFvcGFvOiBjYy5Ob2RlLFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5wYW9wYW8uc2NhbGUgPSBNYXRoLnJhbmRvbSgpICogMC43ICsgMC4zO1xuICAgICAgICAvLyB0aGlzLm9mZnNldFggPSAoTWF0aC5yYW5kb20oKSAqIDIgLSAxKSAqIDAuMTtcbiAgICB9LFxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuICAgICAgICAvLyB0aGlzLnBhb3Bhby54ICs9IHRoaXMub2Zmc2V0WDtcbiAgICAgICAgdGhpcy5wYW9wYW8ueSArPSAyLjA7XG4gICAgICAgIGlmICh0aGlzLnBhb3Bhby55ID49IDEwMTIpIHtcbiAgICAgICAgICAgIHRoaXMucGFvcGFvLnNjYWxlID0gTWF0aC5yYW5kb20oKSAqIDAuNyArIDAuMztcbiAgICAgICAgICAgIHRoaXMucGFvcGFvLnkgPSAwLjA7XG4gICAgICAgIH1cbiAgICB9LFxufSk7XG4iLCJjYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBmZWVkYmFjazogY2MuTm9kZSxcbiAgICAgICAgbG9uZ3hpYTogY2MuTm9kZSxcbiAgICAgICAgZ29uZ3hpbmk6IGNjLk5vZGUsXG4gICAgICAgIHlhb2ppYXlvdTogY2MuTm9kZSxcbiAgICAgICAgc2hpamlhbmRhbzogY2MuTm9kZSxcbiAgICB9LFxuXG4gICAgc2hvd0ZlZWRiYWNrOiBmdW5jdGlvbiAoZmVlZGJhY2tUeXBlKSB7XG4gICAgICAgIHRoaXMubG9uZ3hpYUFuaW0gPSB0aGlzLmxvbmd4aWEuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbik7XG5cbiAgICAgICAgdGhpcy5mZWVkYmFjay5vcGFjaXR5ID0gMjU1O1xuICAgICAgICB0aGlzLmxvbmd4aWEub3BhY2l0eSA9IDI1NTtcbiAgICAgICAgLy/pgI/mmI7luqbmuJDlj5hcbiAgICAgICAgdGhpcy5mZWVkYmFjay5vcGFjaXR5ID0gMDtcbiAgICAgICAgdGhpcy5mZWVkYmFjay5ydW5BY3Rpb24oY2Muc2VxdWVuY2UoY2MuZmFkZVRvKDEsIDI1NSkpKTtcblxuICAgICAgICBpZiAoZmVlZGJhY2tUeXBlID09PSAxKSB7XG4gICAgICAgICAgICAvL+etlOWvueS6hlxuICAgICAgICAgICAgdGhpcy5sb25neGlhQW5pbS5wbGF5KCdGZWVkYmFja18xJyk7XG5cbiAgICAgICAgICAgIHRoaXMuZ29uZ3hpbmkub3BhY2l0eSA9IDI1NTtcbiAgICAgICAgICAgIHRoaXMueWFvamlheW91Lm9wYWNpdHkgPSAwO1xuICAgICAgICAgICAgdGhpcy5zaGlqaWFuZGFvLm9wYWNpdHkgPSAwO1xuICAgICAgICB9IGVsc2UgaWYgKGZlZWRiYWNrVHlwZSA9PT0gMikge1xuICAgICAgICAgICAgLy/nrZTplJnkuoZcbiAgICAgICAgICAgIHRoaXMubG9uZ3hpYUFuaW0ucGxheSgnRmVlZGJhY2tfMicpO1xuXG4gICAgICAgICAgICB0aGlzLmdvbmd4aW5pLm9wYWNpdHkgPSAwO1xuICAgICAgICAgICAgdGhpcy55YW9qaWF5b3Uub3BhY2l0eSA9IDI1NTtcbiAgICAgICAgICAgIHRoaXMuc2hpamlhbmRhby5vcGFjaXR5ID0gMDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8v5pe26Ze05YiwXG4gICAgICAgICAgICB0aGlzLmxvbmd4aWFBbmltLnBsYXkoJ0ZlZWRiYWNrXzMnKTtcblxuICAgICAgICAgICAgdGhpcy5nb25neGluaS5vcGFjaXR5ID0gMDtcbiAgICAgICAgICAgIHRoaXMueWFvamlheW91Lm9wYWNpdHkgPSAwO1xuICAgICAgICAgICAgdGhpcy5zaGlqaWFuZGFvLm9wYWNpdHkgPSAyNTU7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgYW5pbWF0aW9uU3RvcDogZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLmxvbmd4aWFBbmltLnN0b3AoKTtcblxuICAgICAgICB0aGlzLmZlZWRiYWNrLm9wYWNpdHkgPSAwO1xuICAgICAgICB0aGlzLmxvbmd4aWEub3BhY2l0eSA9IDA7XG4gICAgfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMubm9kZS5zY2FsZSA9IE1hdGgucmFuZG9tKCk7XG4gICAgICAgIC8v6L+Q6KGM5Yqo55S7XG4gICAgICAgIHRoaXMubm9kZS5ydW5BY3Rpb24oY2Muc2VxdWVuY2UoXG4gICAgICAgICAgICBjYy5zcGF3bihcbiAgICAgICAgICAgICAgICBjYy5tb3ZlQnkoMC41LCBjYy5wKDI4MCAqIChNYXRoLnJhbmRvbSgpICogMiAtIDEpLCAyODAgKiAoTWF0aC5yYW5kb20oKSAqIDIgLSAxKSkpLFxuICAgICAgICAgICAgICAgIGNjLnNjYWxlVG8oMC41LCBNYXRoLnJhbmRvbSgpICogMC41ICsgMC41KSxcbiAgICAgICAgICAgICAgICBjYy5yb3RhdGVCeSgwLjUsIE1hdGgucmFuZG9tKCkgKiA5MClcbiAgICAgICAgICAgICksXG4gICAgICAgICAgICBjYy5jYWxsRnVuYyhmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgfSwgdGhpcyksXG4gICAgICAgICkpO1xuICAgIH0sXG59KTtcbiIsIi8vbG9n5pel5b+X5byA5YWzXG53aW5kb3cuQ09OU09MRV9MT0dfT1BFTiA9IHRydWU7XG5cbi8v6L2s5o2iMTbov5vliLbpopzoibLkuLpyZ2JcbmZ1bmN0aW9uIEhFWDJSR0IoaGV4Q29sb3IpIHtcblx0cmV0dXJuIHtcblx0XHRyOiBwYXJzZUludChoZXhDb2xvci5zbGljZSgxLCAzKSwgMTYpLFxuXHRcdGc6IHBhcnNlSW50KGhleENvbG9yLnNsaWNlKDMsIDUpLCAxNiksXG5cdFx0YjogcGFyc2VJbnQoaGV4Q29sb3Iuc2xpY2UoNSwgNyksIDE2KVxuXHR9O1xufVxuXG5mdW5jdGlvbiBSR0IySEVYKHIsIGcsIGIpe1xuXHR2YXIgY29sb3IgPSAnIycgKyBzdHJfcGFkKE1hdGguZmxvb3IocikudG9TdHJpbmcoMTYpLDIsJzAnKSArIHN0cl9wYWQoTWF0aC5mbG9vcihnKS50b1N0cmluZygxNiksMiwnMCcpICsgc3RyX3BhZChNYXRoLmZsb29yKGIpLnRvU3RyaW5nKDE2KSwyLCcwJyk7XG5cdHJldHVybiBjb2xvcjtcbn1cbi8v5Y676Zmk5pS25bC+56m65qC8XG5mdW5jdGlvbiB0cmltKHZhbHVlKSB7XG5cdHZhciB0ZW1wID0gdmFsdWU7XG5cdHZhciBvYmogPSAvXihcXHMqKShbXFxXXFx3XSopKFxcYlxccyokKS87XG5cdGlmIChvYmoudGVzdCh0ZW1wKSkge1xuXHRcdHRlbXAgPSB0ZW1wLnJlcGxhY2Uob2JqLCAnJDInKTsgXG5cdH1cblx0b2JqID0gL14oXFxzKikkLztcblx0aWYgKG9iai50ZXN0KHRlbXApKSB7XG5cdFx0dGVtcCA9ICcnOyBcblx0fVxuXG5cdHJldHVybiB0ZW1wO1xufVxuLy/ovazmjaLkuLrmlbTmlbBcbmZ1bmN0aW9uIHRvSW50KHN0cil7XG5cdHZhciByZXN1bHQgPSBwYXJzZUludChzdHIsIDEwKTtcblx0cmV0dXJuIGlzTmFOKHJlc3VsdCkgPyAwIDogcmVzdWx0O1xufVxuLy/mmK/lkKbkuLrmlbDlrZdcbmZ1bmN0aW9uIGlzTnVtKG51bSl7XG5cdHZhciBydWxlID0gL15cXGQrJC87IFxuXHRpZihydWxlLnRlc3QobnVtKSlyZXR1cm4gdHJ1ZTtcblx0cmV0dXJuIGZhbHNlO1xufSBcbi8v5Y+WbWluLW1heOWMuumXtOeahOmaj+acuuaVsFxuZnVuY3Rpb24gcmFuZChtaW4sIG1heCl7XG5cdHZhciBSYW5nZSA9IG1heCAtIG1pbjsgXG5cdHZhciBSYW5kID0gTWF0aC5yYW5kb20oKTsgXG5cdHJldHVybihtaW4gKyBNYXRoLnJvdW5kKFJhbmQgKiBSYW5nZSkpOyBcbn1cbi8qKlxuICog57uf6K6h5a2X56ym5Liy6ZW/5bqm77yM5Lit5paHMueahOmVv+W6plxuICogQHJldHVybnNcbiAqL1xuU3RyaW5nLnByb3RvdHlwZS5sZW4gPSBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy5yZXBsYWNlKC9bXlxceDAwLVxceGZmXS9nLCBcIioqXCIpLmxlbmd0aDtcbn07XG4vKipcbiAqIOWtl+espuS4suaIquWPllxuICogQHBhcmFtIGxlblxuICogQHJldHVybnNcbiAqL1xuU3RyaW5nLnByb3RvdHlwZS5jdXRTdHIgPSBmdW5jdGlvbihuKSB7XG5cdHZhciByID0gL1teXFx4MDAtXFx4ZmZdL2c7XG5cdFxuXHRpZiAodGhpcy5yZXBsYWNlKHIsIFwiKipcIikubGVuZ3RoIDw9IG4pIHJldHVybiB0aGlzO1xuXHR2YXIgbmV3X3N0ciA9IFwiXCI7XG5cdHZhciBzdHIgPSBcIlwiO1xuXHRmb3IgKHZhciBpPTAsaiA9IDA7IGk8dGhpcy5sZW5ndGggJiYgaiA8IG4gOyBpKyspIHtcblx0XHRzdHIgPSB0aGlzLnN1YnN0cihpLCAxKTtcblx0XHRuZXdfc3RyKz1zdHI7XG5cdFx0aiArPSAoc3RyLnJlcGxhY2UocixcIioqXCIpLmxlbmd0aCA+IDEpID8gMiA6IDE7XG5cdH1cblx0cmV0dXJuIG5ld19zdHIgKyBcIiAuLlwiO1xufTtcbi8qKlxuICog5pu/5o2i5a2X56ym5Liy5Lit55qE5a2X56ymXG4gKiBAcGFyYW0gc3RyXG4gKiBAcGFyYW0gcmVwbGFjZV93aGF0XG4gKiBAcGFyYW0gcmVwbGFjZV93aXRoXG4gKiBAcmV0dXJuc1xuICovXG5mdW5jdGlvbiBzdHJfcmVwbGFjZShzdHIsIHJlcGxhY2Vfd2hhdCwgcmVwbGFjZV93aXRoKSB7XG5cdHZhciBuZHggPSBzdHIuaW5kZXhPZihyZXBsYWNlX3doYXQpO1xuXHR2YXIgZGVsdGEgPSByZXBsYWNlX3dpdGgubGVuZ3RoIC0gcmVwbGFjZV93aGF0Lmxlbmd0aDtcblx0d2hpbGUgKG5keCA+PSAwKSB7XG5cdFx0c3RyID0gc3RyLnN1YnN0cmluZygwLCBuZHgpICsgcmVwbGFjZV93aXRoICsgc3RyLnN1YnN0cmluZyhuZHggKyByZXBsYWNlX3doYXQubGVuZ3RoKTtcblx0XHRuZHggPSBzdHIuaW5kZXhPZihyZXBsYWNlX3doYXQsIG5keCArIGRlbHRhICsgMSk7XG5cdH1cblx0cmV0dXJuIHN0cjtcbn1cbi8vIGFsZXJ0KCByZWFkQ29va2llKFwibXlDb29raWVcIikgKTtcbmZ1bmN0aW9uIHJlYWRDb29raWUobmFtZSlcbntcblx0dmFyIGNvb2tpZVZhbHVlID0gXCJcIjtcblx0dmFyIHNlYXJjaCA9IG5hbWUgKyBcIj1cIjtcblx0aWYoZG9jdW1lbnQuY29va2llLmxlbmd0aCA+IDApXG5cdHsgXG5cdFx0b2Zmc2V0ID0gZG9jdW1lbnQuY29va2llLmluZGV4T2Yoc2VhcmNoKTtcblx0XHRpZiAob2Zmc2V0ICE9IC0xKVxuXHRcdHsgXG5cdFx0XHRvZmZzZXQgKz0gc2VhcmNoLmxlbmd0aDtcblx0XHRcdGVuZCA9IGRvY3VtZW50LmNvb2tpZS5pbmRleE9mKFwiO1wiLCBvZmZzZXQpO1xuXHRcdFx0aWYgKGVuZCA9PSAtMSkgZW5kID0gZG9jdW1lbnQuY29va2llLmxlbmd0aDtcblx0XHRcdFx0Y29va2llVmFsdWUgPSB1bmVzY2FwZShkb2N1bWVudC5jb29raWUuc3Vic3RyaW5nKG9mZnNldCwgZW5kKSlcblx0XHR9XG5cdH1cblx0cmV0dXJuIGNvb2tpZVZhbHVlO1xufVxuLy90aW1lPeenklxuZnVuY3Rpb24gd3JpdGVDb29raWUobmFtZSwgdmFsdWUsIHRpbWUpXG57XG5cdHZhciBleHBpcmUgPSBcIlwiO1xuXHRpZih0aW1lICE9IG51bGwpXG5cdHsvL2RvbWFpbj0uYmFpZHUuY29tXG5cdFx0ZXhwaXJlID0gbmV3IERhdGUoKG5ldyBEYXRlKCkpLmdldFRpbWUoKSArIHRpbWUgKiAxMDAwKTtcblx0XHRleHBpcmUgPSBcIjsgZXhwaXJlcz1cIiArIGV4cGlyZS50b0dNVFN0cmluZygpO1xuXHR9XG5cdGV4cGlyZSArPSBcIjsgcGF0aD0vXCI7XG5cdFxuXHRkb2N1bWVudC5jb29raWUgPSBuYW1lICsgXCI9XCIgKyBlc2NhcGUodmFsdWUpICsgZXhwaXJlO1xufVxuXG5mdW5jdGlvbiBnZXRUaW1lKCl7XG5cdHJldHVybiAobmV3IERhdGUoKSkuZ2V0VGltZSgpO1xufVxuXG4vLz09PT096Kej5YazanPmta7ngrnov5DnrpdidWc8PDxcblxuLy/pmaTms5Xlh73mlbDvvIznlKjmnaXlvpfliLDnsr7noa7nmoTpmaTms5Xnu5Pmnpxcbi8v6LCD55So77yaYWNjRGl2KGFyZzEsYXJnMilcbi8v6L+U5Zue5YC877yaYXJnMemZpOS7pWFyZzLnmoTnsr7noa7nu5PmnpxcbmZ1bmN0aW9uIGFjY0RpdihhcmcxLCBhcmcyKSB7XG5cdC8vIHZhciB0MSA9IDAsXG5cdC8vIFx0dDIgPSAwLFxuXHQvLyBcdHIxLCByMjtcblx0Ly8gdHJ5IHtcblx0Ly8gXHR0MSA9IGFyZzEudG9TdHJpbmcoKS5zcGxpdChcIi5cIilbMV0ubGVuZ3RoXG5cdC8vIH0gY2F0Y2ggKGUpIHt9XG5cdC8vIHRyeSB7XG5cdC8vIFx0dDIgPSBhcmcyLnRvU3RyaW5nKCkuc3BsaXQoXCIuXCIpWzFdLmxlbmd0aFxuXHQvLyB9IGNhdGNoIChlKSB7fVxuXHQvLyB3aXRoKE1hdGgpIHtcblx0Ly8gXHRyMSA9IE51bWJlcihhcmcxLnRvU3RyaW5nKCkucmVwbGFjZShcIi5cIiwgXCJcIikpXG5cdC8vIFx0cjIgPSBOdW1iZXIoYXJnMi50b1N0cmluZygpLnJlcGxhY2UoXCIuXCIsIFwiXCIpKVxuXHQvLyBcdHJldHVybiAocjEgLyByMikgKiBwb3coMTAsIHQyIC0gdDEpO1xuXHQvLyB9XG59XG4vL+e7mU51bWJlcuexu+Wei+WinuWKoOS4gOS4qmRpduaWueazle+8jOiwg+eUqOi1t+adpeabtOWKoOaWueS+v+OAglxuTnVtYmVyLnByb3RvdHlwZS5kaXYgPSBmdW5jdGlvbihhcmcpIHtcblx0cmV0dXJuIGFjY0Rpdih0aGlzLCBhcmcpO1xufVxuLy/kuZjms5Xlh73mlbDvvIznlKjmnaXlvpfliLDnsr7noa7nmoTkuZjms5Xnu5Pmnpxcbi8v6LCD55So77yaYWNjTXVsKGFyZzEsYXJnMilcbi8v6L+U5Zue5YC877yaYXJnMeS5mOS7pWFyZzLnmoTnsr7noa7nu5PmnpxcbmZ1bmN0aW9uIGFjY011bChhcmcxLCBhcmcyKSB7XG5cdHZhciBtID0gMCxcblx0XHRzMSA9IGFyZzEudG9TdHJpbmcoKSxcblx0XHRzMiA9IGFyZzIudG9TdHJpbmcoKTtcblx0dHJ5IHtcblx0XHRtICs9IHMxLnNwbGl0KFwiLlwiKVsxXS5sZW5ndGhcblx0fSBjYXRjaCAoZSkge31cblx0dHJ5IHtcblx0XHRtICs9IHMyLnNwbGl0KFwiLlwiKVsxXS5sZW5ndGhcblx0fSBjYXRjaCAoZSkge31cblx0cmV0dXJuIE51bWJlcihzMS5yZXBsYWNlKFwiLlwiLCBcIlwiKSkgKiBOdW1iZXIoczIucmVwbGFjZShcIi5cIiwgXCJcIikpIC8gTWF0aC5wb3coMTAsIG0pXG59XG5cbi8v57uZTnVtYmVy57G75Z6L5aKe5Yqg5LiA5LiqbXVs5pa55rOV77yM6LCD55So6LW35p2l5pu05Yqg5pa55L6/44CCXG5OdW1iZXIucHJvdG90eXBlLm11bCA9IGZ1bmN0aW9uKGFyZykge1xuXHRyZXR1cm4gYWNjTXVsKGFyZywgdGhpcyk7XG59XG5cbi8v5Yqg5rOV5Ye95pWw77yM55So5p2l5b6X5Yiw57K+56Gu55qE5Yqg5rOV57uT5p6cXG4vL+iwg+eUqO+8mmFjY0FkZChhcmcxLGFyZzIpXG4vL+i/lOWbnuWAvO+8mmFyZzHliqDkuIphcmcy55qE57K+56Gu57uT5p6cXG5mdW5jdGlvbiBhY2NBZGQoYXJnMSwgYXJnMikge1xuXHR2YXIgcjEsIHIyLCBtO1xuXHR0cnkge1xuXHRcdHIxID0gYXJnMS50b1N0cmluZygpLnNwbGl0KFwiLlwiKVsxXS5sZW5ndGhcblx0fSBjYXRjaCAoZSkge1xuXHRcdHIxID0gMFxuXHR9XG5cdHRyeSB7XG5cdFx0cjIgPSBhcmcyLnRvU3RyaW5nKCkuc3BsaXQoXCIuXCIpWzFdLmxlbmd0aFxuXHR9IGNhdGNoIChlKSB7XG5cdFx0cjIgPSAwXG5cdH1cblx0bSA9IE1hdGgucG93KDEwLCBNYXRoLm1heChyMSwgcjIpKVxuXHRyZXR1cm4gKGFyZzEgKiBtICsgYXJnMiAqIG0pIC8gbVxufVxuXG4vL+e7mU51bWJlcuexu+Wei+WinuWKoOS4gOS4qmFkZOaWueazle+8jOiwg+eUqOi1t+adpeabtOWKoOaWueS+v+OAglxuTnVtYmVyLnByb3RvdHlwZS5hZGQgPSBmdW5jdGlvbihhcmcpIHtcblx0cmV0dXJuIGFjY0FkZChhcmcsIHRoaXMpO1xufVxuXG4vL+WHj+azleWHveaVsO+8jOeUqOadpeW+l+WIsOeyvuehrueahOWHj+azlee7k+aenFxuLy/osIPnlKjvvJphY2NTdWIoYXJnMSxhcmcyKVxuLy/ov5Tlm57lgLzvvJphcmcx5YeP5Y67YXJnMueahOeyvuehrue7k+aenFxuZnVuY3Rpb24gYWNjU3ViKGFyZzEsIGFyZzIpIHtcblx0dmFyIHIxLCByMiwgbSwgbjtcblx0dHJ5IHtcblx0XHRyMSA9IGFyZzEudG9TdHJpbmcoKS5zcGxpdChcIi5cIilbMV0ubGVuZ3RoXG5cdH0gY2F0Y2ggKGUpIHtcblx0XHRyMSA9IDBcblx0fVxuXHR0cnkge1xuXHRcdHIyID0gYXJnMi50b1N0cmluZygpLnNwbGl0KFwiLlwiKVsxXS5sZW5ndGhcblx0fSBjYXRjaCAoZSkge1xuXHRcdHIyID0gMFxuXHR9XG5cdG0gPSBNYXRoLnBvdygxMCwgTWF0aC5tYXgocjEsIHIyKSk7XG5cdC8vIGxhc3QgbW9kaWZ5IGJ5IGRlZWthXG5cdC8vIOWKqOaAgeaOp+WItueyvuW6pumVv+W6plxuXHRuID0gKHIxID49IHIyKSA/IHIxIDogcjI7XG5cdHJldHVybiAoKGFyZzEgKiBtIC0gYXJnMiAqIG0pIC8gbSkudG9GaXhlZChuKTtcbn1cblxuLy/nu5lOdW1iZXLnsbvlnovlop7liqDkuIDkuKphZGTmlrnms5XvvIzosIPnlKjotbfmnaXmm7TliqDmlrnkvr/jgIJcbk51bWJlci5wcm90b3R5cGUuc3ViID0gZnVuY3Rpb24oYXJnKSB7XG5cdFx0cmV0dXJuIGFjY1N1YihhcmcsIHRoaXMpO1xufVxuLy8gPT09PT3op6PlhrNqc+a1rueCuei/kOeul2J1Zz4+PiIsImNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIG9wdGlvbl9ub2RlOiBjYy5Ob2RlLFxuICAgICAgICBsYWJlbDogY2MuTGFiZWxcbiAgICB9LFxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIHRoaXMudG91Y2hfc3RhcnQuYmluZCh0aGlzKSwgdGhpcy5ub2RlKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsIHRoaXMudG91Y2hfbW92ZSwgdGhpcy5ub2RlKTtcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCwgdGhpcy50b3VjaF9lbmQuYmluZCh0aGlzKSwgdGhpcy5ub2RlKTtcbiAgICB9LFxuICAgIGluaXQ6IGZ1bmN0aW9uIChnYW1lSlMsIG9wdGlvbiwgb3B0aW9uTGVuZ3RoKSB7XG4gICAgICAgIHRoaXMubm9kZS5vcGFjaXR5ID0gMjU1O1xuICAgICAgICB0aGlzLmdhbWVKUyA9IGdhbWVKUztcbiAgICAgICAgdGhpcy5vcHRpb24gPSBvcHRpb247Ly/pgInpobnvvIjpgInpobnvvIzpgInpobnnrZTmoYjvvIlcbiAgICAgICAgdGhpcy5sYWJlbC5zdHJpbmcgPSBvcHRpb24ub3B0aW9uQ29udGVudDsvL+ivu+WPlumAiemhueetlOahiFxuICAgICAgICB0aGlzLm9wdGlvbk5vID0gb3B0aW9uLm9wdGlvbk5vO1xuICAgIH0sXG4gICAgdG91Y2hfc3RhcnQ6IGZ1bmN0aW9uKGV2dCl7XG4gICAgICAgIHRoaXMub3BhY2l0eSA9IDE1MDtcbiAgICAgICAgdGhpcy5zdGFydHggPSB0aGlzLm5vZGUueDtcbiAgICAgICAgdGhpcy5zdGFydHkgPSB0aGlzLm5vZGUueTtcbiAgICB9LFxuICAgIHRvdWNoX2VuZDpmdW5jdGlvbihldnQpe1xuICAgICAgICB0aGlzLm5vZGUub3BhY2l0eSA9IDI1NTtcbiAgICAgICAgdmFyIGlzVG91Y2ggPSB0aGlzLmNoZWNrKCk7XG4gICAgICAgIGlmKGlzVG91Y2gpe1xuICAgICAgICAgICAgdGhpcy5vcHRpb25DbGljaygpO1xuICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgIHRoaXMubm9kZS54ID0gdGhpcy5zdGFydHg7XG4gICAgICAgICAgICB0aGlzLm5vZGUueSA9IHRoaXMuc3RhcnR5O1xuICAgICAgICB9XG4gICAgfSxcbiAgICB0b3VjaF9tb3ZlOmZ1bmN0aW9uKGV2dCl7XG4gICAgICAgIHZhciBkZWx0YSA9IGV2dC50b3VjaC5nZXREZWx0YSgpO1xuICAgICAgICB0aGlzLnggKz0gZGVsdGEueDtcbiAgICAgICAgdGhpcy55ICs9IGRlbHRhLnk7IFxuICAgIH0sXG4gICAgY2hlY2s6ZnVuY3Rpb24oKXtcbiAgICAgICAgdmFyIG5vZGUgPSB0aGlzLnF1ZXN0aW9uTm9kZTtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzLm5vZGU7XG4gICAgICAgIGlmKCghdGhpcy5pc1NlbGVjdGVkKSAmJiBNYXRoLmFicyggbm9kZS54IC0gc2VsZi54ICkgPCAobm9kZS53aWR0aCArIHNlbGYud2lkdGgpLzIgJiYgTWF0aC5hYnMoIG5vZGUueSAtIHNlbGYueSArIDY1MCApIDwgKG5vZGUuaGVpZ2h0ICsgc2VsZi5oZWlnaHQpLzIpe1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgb3B0aW9uQ2xpY2s6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5ub2RlLm9wYWNpdHkgPSAwO1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHNlbGYudXBkYXRlU3RhdGUoZmFsc2UpO1xuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBzZWxmLmdhbWVKUy5zZWxlY3RBbnN3ZXIoc2VsZi5vcHRpb24pO1xuICAgICAgICB9LCAwLjIpO1xuICAgIH0sXG4gICAgLy/mjInpkq7mmK/lkKblj6/ngrnlh7tcbiAgICB1cGRhdGVTdGF0ZTogZnVuY3Rpb24gKGludGVyYWN0YWJsZSkge1xuICAgICAgICB2YXIgYnV0dG9uQ29tID0gdGhpcy5vcHRpb25fbm9kZS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKTtcbiAgICAgICAgYnV0dG9uQ29tLmludGVyYWN0YWJsZSA9IGludGVyYWN0YWJsZTtcbiAgICB9LFxuICAgIHNldFF1ZXN0aW9uTm9kZTogZnVuY3Rpb24ocXVlc3Rpb25Ob2RlKXtcbiAgICAgICAgdGhpcy5xdWVzdGlvbk5vZGUgPSBxdWVzdGlvbk5vZGU7XG4gICAgfVxufSk7XG4iLCJjYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICBsYWJlbDogY2MuTGFiZWwsXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xuXG4gICAgfSxcbiAgICBjbGlja0Z1bjogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51cGRhdGVTdGF0ZShmYWxzZSk7XG4gICAgICAgIHRoaXMudGFyZ2V0LnNlbGVjdEFuc3dlcih0aGlzLnRleHRUZW1wLm9wdGlvbk5vKTtcbiAgICB9LFxuICAgIHRleHRJbml0IDogZnVuY3Rpb24gKHRhcmdldCx0ZXh0VGVtcCkge1xuICAgICAgICB0aGlzLmxhYmVsLnN0cmluZyA9IHRleHRUZW1wLm9wdGlvbkNvbnRlbnQ7XG4gICAgICAgIHRoaXMudGFyZ2V0ID0gdGFyZ2V0O1xuICAgICAgICB0aGlzLnRleHRUZW1wID0gdGV4dFRlbXA7XG4gICAgfSxcbiAgICB1cGRhdGVTdGF0ZSA6IGZ1bmN0aW9uKHN0YXRlKSB7XG4gICAgICAgIHZhciBidXR0b25Db20gPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG4gICAgICAgIGJ1dHRvbkNvbS5pbnRlcmFjdGFibGUgPSBzdGF0ZTtcbiAgICB9LFxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==